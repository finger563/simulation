
/*
 * roamstep1.c       ROAM example 1: simple split-only recursion
 * by Mark Duchaineau (free but copyrighted, see LibGen/COPYING)
 *
 * The very simplest ROAM-like optimization is to perform pure
 * recursion on the triangle bintree without crack fixups, queues
 * or any of the later optimizations.  Indeed, here we don't even
 * read elevation data, but synthesize if on the fly in the recursion,
 * creating a fractal terrain through midpoint displacement.
 *
 * 2002-08-01: wrote inital version
 * 2002-08-03: defined roam.h API and modified this to use it
 *
 */


#include "randtab.h"  /* randomizer hashing tables                          */
#include "fly.h"      /* wrapper of window/event support for flight apps    */
#include "roam.h"     /* our own defs                                       */
#include "roamtypes.h"/* internal defs                                      */


int roam_lmax;          /* current max recursion level                      */
float xcf,ycf,zcf;      /* float copy of camera position in world space     */
float frust_planes[6][4]; /* copy of frustum plane coefficients             */
float level2dzsize[ROAM_LMAX+1]; /* max midpoint displacement per level     */


/* bintree recurse */
static void drawsub(fly fl,int l,float *v0,float *v1,float *v2);


roamhandle roam_create(fly fl)
{
    printf("ROAM example library, step 1: simple recursive split\n");

    roam_lmax=ROAM_LMAX;

    /* generate table of displacement sizes versus level */
    {
        int l;

        for (l=0;l<=ROAM_LMAX;l++)
        level2dzsize[l]=0.3f/sqrt((float)((roam_int64)1<<l));
    }

    return (roamhandle)0;
}


void roam_set_frustum(roamhandle rmh,fly fl)
{
    /* all we care about at this step is the eyepoint */
    xcf=fl->uvwxyz[9]; ycf=fl->uvwxyz[10]; zcf=fl->uvwxyz[11];
}


void roam_set_tricntmax(roamhandle rmh,int tricntmax)
{
    /* meaningless for this version of the library */
}


void roam_set_lmax(roamhandle rmh,int lmax)
{
    roam_lmax=lmax;
}


void roam_set_iqfine(roamhandle rmh,int iqfine)
{
    /* not implemented yet for this version of the library */
}


void roam_draw(roamhandle rmh,fly fl)
{
    /* turn on textured drawing (with the grid texture for now) */
    glBindTexture(GL_TEXTURE_2D,fl->gridtex_id);
    glEnable(GL_TEXTURE_2D);

    /* draw a roam mesh */
    {
        int i;
        float v[4][3];

        /* compute four corners of the base square */
        for (i=0;i<4;i++) {
            v[i][0]=((i&1)?1.0f:-1.0f);
            v[i][1]=((i&2)?1.0f:-1.0f);
            v[i][2]=0.0f;
        }

        /* recurse on the two base triangles */
        drawsub(fl,0,v[0],v[1],v[3]);
        drawsub(fl,0,v[3],v[2],v[0]);
    }

    /* stop texturing the draws */
    glDisable(GL_TEXTURE_2D);
}



/*
 * ========== internal routines ==========
 */


/*
 * recursively draw a bintree triangle
 *
 * this version does no caching or crack fixups
 * recursion terminates when triangle error projection is small or
 * at level limit
 *
 * orientation of vertices:
 *
 *                     v1
 *                    /.\
 *                   / . \
 *                  /  .  \
 *                 /   .   \
 *                /    .    \
 *               v2----o----v0
 *                     ^
 *                     vc
 */

static void drawsub(fly fl,int l,float *v0,float *v1,float *v2)
{
    float vc[3]; /* new (split) vertex */
    float ds; /* maximum midpoint displacement */
    float dx,dy,dz; /* difference vector */
    float rd; /* squared sphere bound radius */
    float rc; /* squared distance from vc to camera position */

    /* compute split point of base edge */
    vc[0]=0.5f*(v0[0]+v2[0]);
    vc[1]=0.5f*(v0[1]+v2[1]);
    RANDHASHF((unsigned char *)vc,8,dz)
    ds=level2dzsize[l];
    vc[2]=0.5f*(v0[2]+v2[2])+dz*ds;

    /* compute radius of diamond bounding sphere (squared) */
    rd=0.0f;
    dx=v0[0]-vc[0]; dy=v0[1]-vc[1]; dz=v0[2]-vc[2];
    rc=dx*dx+dy*dy+dz*dz; if (rc>rd) rd=rc;
    dx=v1[0]-vc[0]; dy=v1[1]-vc[1]; dz=v1[2]-vc[2];
    rc=dx*dx+dy*dy+dz*dz; if (rc>rd) rd=rc;
    dx=v2[0]-vc[0]; dy=v2[1]-vc[1]; dz=v2[2]-vc[2];
    rc=dx*dx+dy*dy+dz*dz; if (rc>rd) rd=rc;

    /* compute distance from split point to camera (squared) */
    dx=vc[0]-xcf; dy=vc[1]-ycf; dz=vc[2]-zcf;
    rc=dx*dx+dy*dy+dz*dz;

    /* if not max level and error large on screen, recursively split */
    if (l<roam_lmax && ds*ds>rc*0.00001f) {
        drawsub(fl,l+1,v0,vc,v1);
        drawsub(fl,l+1,v1,vc,v2);
        return;
    }

    /* leaf of recursion (small projected error or max level): draw tri */
    glBegin(GL_TRIANGLE_STRIP);
    glTexCoord2fv(fl->gridtex_t[0]); glVertex3fv(v0);
    glTexCoord2fv(fl->gridtex_t[1]); glVertex3fv(v1);
    glTexCoord2fv(fl->gridtex_t[2]); glVertex3fv(v2);
    glEnd();
}


