
ROAM tutorial code, presented in several stages.

by Mark Duchaineau (free but copyrighted, see LibGen/COPYING)

2002-08-07: wrote first vertion
2002-08-18: added details to Win32 build notes


--- COMPILE ---

To compile under unix-like systems:

   ./genroamsteps

Under Win32/MSVC systems:

   1) make sure you have GLUT from
      http://www.xmission.com/~nate/glut.html

   2a) batch build using: buildvc.bat
    -- OR --
   2b) click on roamsteps.dsw and build using the MSVC IDE

To clean up (remove files produced by compile):

   Unix-like systems: ./cleanroamsteps

   Win32 batch: cleanvc.bat


--- RUNNING THE DEMOS ---

The executables are roamfly1, roamfly2, etc (with .exe on Win32).

Left button drag to rotate view
'a'/'z'  -- accelerate forward and reverse
' '      -- stop
'<'/'>'  -- decrease/increase max level of detail
'i'/'I'  -- increase/decrease quality limit ("tolerance")
'0'-'9'  -- enter a number to modify the next command (set to zero on next key)
'v'      -- load camera parameters from file viewpointN.txt
            where N is the number you just entered
ctrl-V   -- save camera parameters to viewpointN.txt
'V'      -- play the flight loop defined by viewpoint{0-9}.txt
            if N>0, set loop time to N seconds:
              20=hyperfast, 40=fast, 60=normal, 120=slow
            displays ave frames/sec once per loop
'l'/'L'  -- display/hide flight loop
's'/'S'  -- show/skip stats output
'f'/'F'  -- freeze/unfreeze the mesh
esc      -- quit

NOTES ON BENCHMARKING:

  static viewpoint: use ctrl-V then v to save and load same view
  for different versions of the code.  Then type 's' to show frames/sec.

  flight loop: use 'V'--the ave frames/sec is show once per loop.
  Loop times can be controlled--see notes on RUNNING THE DEMOS above.


--- SOURCE CODE ---

randtab.*      -- general-purpose randomizer hash utility library

fly.*          -- portability wrapper for simple flight applications

roam.h         -- roam library API from application point of view,
                  common to all implementations of the library

roamtypes.h    -- common definitions, types, structures for most roam
                  library implementations

roamfly.c      -- demo application of the roam library implementations...
                  this is the one source file with main() in it

roamfly1 etc   -- roamfly.c compiled with each of the library implementations

roamstepN.c    -- various library implementations of gradually increasing
                  complexity and performance

roamstep1.c    -- simplest possible bintree recursion, fractal terrain
                  no frustum cull, no caching, no crack fixes...

roamstep2.c    -- adds frustum cull to simple recursion

roamstep3.c    -- introduces backbone data structure, the diamond (roamdm).
                  Adds caching.  For simple fractal generation, does not
                  make a huge difference (static view is faster, flight loop
                  is a bit slower).  However, the caching would give
                  significant speed gains for more complex heightmap
                  generation (high quality fractals for example).  More
                  important, allows future optimizations such as
                  split/merge with dual priority queues.

roamstep4.c    -- introduces the two bucket-based queues for split/merge,
                  and the optimization procedure that drives its use on a
                  time budget each frame.

roamstep5.c    -- (TO DO) will add tiling subsystem, AGP/displaylist chunking

For Unix-only use, ignore all the .plg, .dsp, .dsw, .ncb, .opt, .bat
files and the Debug directory: these are only used for Win32 builds.
For Win32-only use, ignore the genroamsteps* and cleanroamsteps
shell scripts, as these only apply to Unix-style builds.
Note that for Win32 binary-only distributions, the file glut32.dll
must be included.


