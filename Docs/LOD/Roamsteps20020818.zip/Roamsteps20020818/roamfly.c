
/*
 * roamfly.c    common application that can use any of the roamstepX libraries
 * by Mark Duchaineau (free but copyrighted, see LibGen/COPYING)
 *
 * 2002-08-01: wrote inital version
 * 2002-08-03: teased out roamstepN libraries from this code
 * 2002-08-10: added show_stats 's'/'S' control
 * 2002-08-18: moved roam init to occur on first fly event
 *
 */


#include "randtab.h"  /* randomizer hashing tables                          */
#include "fly.h"      /* wrapper of window/event support for flight apps    */
#include "roam.h"     /* common header for all the roamstepN.c libraries    */


/* handle from roam_create() */
roamhandle rmh;

/* maximum display refinement level */
int started,level_max,iq_fine;
int show_stats;


/*
 * local routines
 */

/* fly event handler */
void fevent(fly fl);

/* draws the 3D scene */
void do_draw(fly fl);


int main(int argc,char **argv,char **envp)
{
    started=0;
    show_stats=0;
    level_max=ROAM_LMAX;
    iq_fine=1971;

    fly_launch("ROAM flight test 'a'/'z'/' '",800,600,fevent);

    exit(0);
}


void fevent(fly fl)
{
    /* do init on first event */
    if (!started) {
        started=1;
        rmh=roam_create(fl);
        roam_set_lmax(rmh,level_max);
        roam_set_iqfine(rmh,iq_fine);
    }

    switch (fl->eventnum) {
    case FLY_DRAW:
        do_draw(fl);
        break;
    case FLY_KEY:
        switch (fl->key) {
        case 's':
        case 'S':
            show_stats=(fl->key=='s'?1:0);
            break;
        case '>':
            if (level_max<ROAM_LMAX) level_max++;
            roam_set_lmax(rmh,level_max);
            printf("level_max=%d\n",level_max);
            break;
        case '<':
            if (level_max>0) level_max--;
            roam_set_lmax(rmh,level_max);
            printf("level_max=%d\n",level_max);
            break;
        case 'I':
        case 'i':
            iq_fine+=(fl->key=='I'?1:-1);
            roam_set_iqfine(rmh,iq_fine);
            break;
        default:
            break;
        }
        break;
    case FLY_QUIT:
        fly_exit(fl,0);
        break;
    default:
        break;
    }
}


void do_draw(fly fl)
{
    /* print frames/sec to the console every so often */
    if (show_stats) {
        static int framecnt = 0;
        static double tim0 = 0.0;
        double tim1;

        if (framecnt==0) {
            tim0=fly_usec(fl);
        }else{
            if (framecnt%100==0) {
                tim1=fly_usec(fl);
                printf("ave. frames/sec = %g\n",1.0/(1e-6*(tim1-tim0)/100.0));
                tim0=tim1;
            }
        }
        framecnt++;
        if (framecnt>1000000) framecnt-=100;
    }

    /* freeze the mesh by not updating roam's frustum copy */
    if (!fl->freeze) roam_set_frustum(rmh,fl);

    /* optimize and draw the roam mesh */
    roam_draw(rmh,fl);
}


