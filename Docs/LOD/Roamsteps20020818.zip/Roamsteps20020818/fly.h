
#ifndef FLY__HERE
#define FLY__HERE 1

/*
 * fly.h       simple wrapper of event and window support for flying around
 * by Mark Duchaineau (free but copyrighted, see LibGen/COPYING)
 *
 * see fly.c for more documentation, data structures and calls are
 * documented below.
 *
 * 2002-08-01: first version
 * 2002-08-02: added frust_planes[6][4] for frustum culling
 * 2002-08-10: flight loop stuff
 * 2002-08-18: wall-clock time for manual flight motion
 *
 */


#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <GL/glut.h>


typedef struct fly_structdef fly_struct,*fly;


/* event types given in fl->eventnum */
#define FLY_DRAW      1
#define FLY_KEY       2
#define FLY_QUIT      3


typedef void (*flyevent)(fly fl);


struct fly_structdef {

    /* the following fields are of interest to an application */
    flyevent event;         /* application's callback for fly events        */
    void *data;             /* application-supplied data attachment         */
    int eventnum;           /* event type code (see defs)                   */
    int key;                /* ascii value of key pressed for KEY events    */
    int digits;             /* number entered via keyboard (can modify ops) */
    int wxsize,wysize;      /* current window size                          */
    int freeze;             /* 0=mesh updates requested, 1=no mesh updates  */
    double velocity;        /* flight rate in look direction                */
    double t0;              /* time in usec of last position udate          */
    double uvwxyz[12];      /* view rotation state (0-8 rotation, 9-11 eye) */
    float frust_planes[6][4]; /* six frustum plane equation coefficients    */
    GLuint gridtex_id;      /* texture id to Bind for showing grid          */
    float gridtex_t[3][3];  /*   texture coordinates for three verts        */

    /* the remaining fields are primarily for internal use of the library */
    int window;             /* glut window id                               */
    int mx0,my0;            /* previous mouse position                      */
    int dragrot;            /* 0= not rotating, 1=rotating                  */
    double xc,yc,scale;     /* window center, size (for rotation purposes)  */
    char gridtex_raster[128*128*4]; /* texture for showing mesh             */
    double viewtab[640][12];/* viewpoints 0-9 interpolated for flight loop  */
    double animate_t0;      /* start time of animation loop                 */
    double animate_t;       /* flight loop time 0<=t<10 (t<0 not animating) */
    double animate_tloop;   /* time per loop in usec                        */
    int loop_framecnt;      /* frames drawn per flight loop (benchmark stat)*/
    int loop0;              /* loop number last frame                       */
    int show_loop;          /* 1=show flight loop, 0=hide flight loop       */

};


/*
 * some handy macros
 */

#define NORM(X,Y,Z,R) {                                                      \
    R=sqrt(X*X+Y*Y+Z*Z);                                                     \
    if (R<1e-12) { X=1.0; Y=0.0; Z=0.0; }                                    \
    else { X/=R; Y/=R; Z/=R; }                                               \
}

#define CROSS(BX,BY,BZ,CX,CY,CZ,AX,AY,AZ) {                                  \
    AX=BY*CZ-BZ*CY;                                                          \
    AY=BZ*CX-BX*CZ;                                                          \
    AZ=BX*CY-BY*CX;                                                          \
}


/*
 * create the fly window and never return.  All the application does
 * after this call is respond to callback events.  Events are
 * called as (*fl->event)(fl), where fl->eventnum indicates the type
 * of event.  Fields in the fl structure contain relevant state
 * such as the recent key pressed or the window size.
 */

void fly_launch(char *window_title,int width,int height,flyevent event);
 

/*
 * exit the fly application, error code 0 indicates no error, nonzero if
 * some error condition.  This is usually called from QUIT event
 * handling unless there is an error condition.
 */

void fly_exit(fly fl,int errnum);


/*
 * return system time in usec in a double
 */

double fly_usec(fly fl);


#endif /* ifdef FLY__HERE */


