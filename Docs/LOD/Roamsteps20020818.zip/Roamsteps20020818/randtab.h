
#ifndef RANDTAB__HERE
#define RANDTAB__HERE 1

/*
 * randtab.h             general randomizer hash function via table lookup
 * by Mark Duchaineau (free but copyrighted, see LibGen/COPYING)
 *
 * use RANDHASH(MEM,BYTES,H) to get an unsigned int H from hashing
 * BYTES number of bytes from (char *)MEM
 *
 * use RANDHASHF(MEM,BYTES,F) to get a float F in the range [-1.0,1.0]
 *
 * 2002-08-01: wrote inital version
 *
 */


extern int randtab[2048];


#define RANDHASH(MEM,BYTES,H) {                                              \
    int randhash_i,randhash_s;                                               \
    unsigned char *randhash_cp;                                              \
                                                                             \
    randhash_cp=(unsigned char *)(MEM);                                      \
    for (randhash_i=0,randhash_s=0;randhash_i<(BYTES);randhash_i++)          \
        randhash_s+=randtab[((randhash_i&7)<<8)|randhash_cp[randhash_i]];    \
    (H)=randhash_s;                                                          \
}


#define RANDHASHF(MEM,BYTES,F) {                                             \
    unsigned int randhash_h;                                                 \
    int *randhash_ip;                                                        \
                                                                             \
    RANDHASH(MEM,BYTES,randhash_h)                                           \
    randhash_ip=(int *)(&(F));                                               \
    *randhash_ip=0x40000000+(randhash_h&0x007fffff);                         \
    (F)-=3.0f;                                                               \
}

#endif


