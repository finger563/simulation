
#ifndef ROAM__HERE
#define ROAM__HERE 1

/*
 * roam.h                common header file for roamstepN.c library examples
 * by Mark Duchaineau (free but copyrighted, see LibGen/COPYING)
 *
 * 2002-08-03: wrote
 * 2002-08-13: added _set_tricntmax()
 * 2002-08-17: added _set_iqfine()
 *
 */


#include "fly.h"


/* maximum bintree level for which index-to-float conversions work */
#define ROAM_LMAX 45


/*
 * opaque handle to the roam view-dependent mesh returned from roam_create()
 */

typedef void *roamhandle;


/*
 * make a roam view-dependent mesh
 */

roamhandle roam_create(fly fl);


/*
 * set the frustum used to cull and optimize the mesh
 */

void roam_set_frustum(roamhandle rmh,fly fl);


/*
 * set the target triangle count
 */

void roam_set_tricntmax(roamhandle rmh,int tricntmax);


/*
 * set the maximum bintree refinement level
 */

void roam_set_lmax(roamhandle rmh,int lmax);


/*
 * set the maximum projected accuracy as a priority-queue index
 */

void roam_set_iqfine(roamhandle rmh,int iqfine);


/*
 * optimize the roam mesh for the current frustum and draw it
 *
 * NOTE: roam does not look at what the actual view transform is.
 * So, for debugging you can look at the roam mesh from a
 * different point of view than was used for optimization
 * and culling.
 */

void roam_draw(roamhandle rmh,fly fl);


#endif /* ifndef ROAM__HERE */

