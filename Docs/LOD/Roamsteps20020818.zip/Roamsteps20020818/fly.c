
/*
 * fly.c       simple wrapper of event and window support for flying around
 * by Mark Duchaineau (free but copyrighted, see LibGen/COPYING)
 *
 * This API wrappers whatever underlying window/event API is used, to
 * hide those layers from the rest of the application. This makes the
 * code much more portable.  Also, applications written using the fly API
 * are much shorter since many details are dealt with here.  The wrapper
 * only gives a very simple capability and is not intended to be
 * very general (it is considerably less general than GLUT, but
 * at a somewhat higher level of abstraction).
 *
 * 2002-08-01: wrote inital version
 * 2002-08-08: fixed fly_reshape() to properly avoid a gl call before window up
 * 2002-08-10: digits input, multiple viewpoint files, flight loop, benchmark
 * 2002-08-11: allow variable loop time
 * 2002-08-18: clamped position to sphere to avoid running off to infinity;
 *             tied manual flight velocity to wall clock time; moved viewpoint
 *             files to the viewpoints subdirectory
 *
 */


#include "fly.h"


/* shorthand for the view rotation state entries */
#define UX fl->uvwxyz[0]  /* rotation entries 0..8 */
#define UY fl->uvwxyz[1]
#define UZ fl->uvwxyz[2]
#define VX fl->uvwxyz[3]
#define VY fl->uvwxyz[4]
#define VZ fl->uvwxyz[5]
#define WX fl->uvwxyz[6]
#define WY fl->uvwxyz[7]
#define WZ fl->uvwxyz[8]
#define XC fl->uvwxyz[9] /* position entries 9,10,11 */
#define YC fl->uvwxyz[10]
#define ZC fl->uvwxyz[11]


/*
 * GLUT event handlers
 */

static void fly_mouse(int button,int state,int x,int y);
static void fly_motion(int x,int y);
static void fly_keyboard(unsigned char key,int x,int y);
static void fly_idle(void);
static void fly_drawimage(void);
static void fly_visible(int vis);
static void fly_reshape(int width,int height);


/*
 * view trackball rotation and matrix support
 */

static void fly_dragrotsub(fly fl,double x0,double y0,double x1,double y1);
static void fly_vm_mul(double *vma,double *vmb,double *vmab);
void fly_vm_inv(double *vm,double *vmi);
void fly_vm2planes(fly fl,double *vm);
void fly_pnts2plane(fly fl,int i,double *p0,double *p1,double *p2,double *g);
void fly_keyframe_orthogonalize(double *kf);
void fly_generate_loop(fly fl);


/*
 * global fly record
 *
 * NOTE: would be better to attach to the glut window data somehow, but I
 * haven't looked into how to do that.
 */

fly fly_fl;


/*
 * glut wants these for some strange reason... ;-)
 */

int fly_argc = 1;
static char *fly_argv[2] = { "fly", (char *)0 };


void fly_launch(char *window_title,int width,int height,flyevent event)
{
    fly fl;

    fly_fl=fl=(fly)malloc(sizeof(fly_struct));
    fl->event=event;
    fl->data=(char *)0; /* application can fill this in if it wants */
                        /* not useful at this point since only one fly */
    fl->eventnum=0;
    fl->key=0;
    fl->digits=0;
    fl->wxsize= -1; /* tells reshape that OpenGL not active yet */
    fl->freeze=0;
    fl->velocity=0.0;
    fl->show_loop=0;

    /* generate grid texture */
    {
        int x,y,k;
        float f,a0,a1,a2;

        for (y=0;y<128;y++) {
            for (x=0;x<128;x++) {
                /*
                 * create bump-shaped function f that is zero on each edge
                 */
                #ifdef GRIDTEX_SMOOTH
                    /* simple, smooth triangle texture */
                    a0=(float)y/127.0;
                    a1=(float)(127-x)/127.0;
                    a2=(float)(x-y)/127.0;
                    f=a0*a1*a2; f=sqrt(f);
                #else
                    /* sharper triangle texture shows grid lines nicely */
                    a0=(float)y/127.0;
                    a1=(float)(127-x)/127.0;
                    a2=(float)(x-y)/127.0;
                    f=a0*a1*a2;
                    f-=0.02f; if (f<0.0f) f= -f; f=sqrt(1.5f*f);
                #endif

                /* quantize the function value and make into color */
                /* store in rgb components of texture entry */
                k=(int)floor(1400.0*f);
                if (k<0) k=0; if (k>255) k=255;
                fl->gridtex_raster[4*(y*128+x)+0]=30+(k*k)/290;
                fl->gridtex_raster[4*(y*128+x)+1]=k;
                fl->gridtex_raster[4*(y*128+x)+2]=(k<128?0:(k-128)*2);
                fl->gridtex_raster[4*(y*128+x)+3]=0;
            }
        }

        /* make texture coordinates for three triangle vertices */
        /* all triangles use same tex coords when showing grid */
        /* suck in by half a texel to be correct for bilinear textures */
        a0=0.5f/128.0f; a1=1.0f-a0;
        fl->gridtex_t[0][0]=a0; fl->gridtex_t[0][1]=a0;
        fl->gridtex_t[1][0]=a1; fl->gridtex_t[1][1]=a0;
        fl->gridtex_t[2][0]=a1; fl->gridtex_t[2][1]=a1;
    }

    /* set initial camera orientation and location */
    {
        int i;

        for (i=0;i<12;i++) fl->uvwxyz[i]=0.0;
        UX=1.0; VY=1.0; WZ=1.0;
        XC=0.0; YC= -1.0; ZC=0.3;
    }

    /* startup assuming not already dragging mouse */
    fl->mx0=fl->my0=0; fl->dragrot=0;

    fl->freeze=0; /* start with mesh active */
    fl->velocity=0.0; /* no motion at startup */
    fl->t0=fly_usec(fl);
    fl->animate_t= -1.0; /* initially not animating */
    fl->animate_tloop=40e6;

    fly_reshape(width,height); /* set initial window size */

    /* typical GLUT initalization */
    glutInitWindowSize(fly_fl->wxsize,fly_fl->wysize);
    glutInitWindowPosition(32,32);
    glutInit(&fly_argc,fly_argv);
    glutInitDisplayMode(GLUT_RGBA|GLUT_DEPTH|GLUT_DOUBLE);
    fl->window=glutCreateWindow(window_title);
    glutMotionFunc(fly_motion);
    glutMouseFunc(fly_mouse);
    glutKeyboardFunc(fly_keyboard);
    glutDisplayFunc(fly_drawimage);
    glutReshapeFunc(fly_reshape);
    glutVisibilityFunc(fly_visible);
    glutIdleFunc(fly_idle);

    /* go off forever into GLUT (everything hereafter is callback handling) */
    glutMainLoop();

    exit(0);
}


void fly_exit(fly fl,int errnum)
{
    exit(errnum);
}


double fly_usec(fly fl)
{
    int msec;

    /* on unix systems, gettimeofday() gives very nice usec precision,
     * but I haven't looked into how to get that functionality on other
     * systems.  So we use the lousy msec precision available in Glut
     * for portability.
     */
    msec=glutGet(GLUT_ELAPSED_TIME);
    return (double)msec*1000.0;
}



/*
 * ========== internal routines ==========
 */


static void fly_mouse(int button,int state,int x,int y)
{
    y=fly_fl->wysize-1-y;
    /* do something with mouse info */
    if (button==GLUT_LEFT_BUTTON) {
        if (state==GLUT_DOWN) {
            fly_fl->mx0=x; fly_fl->my0=y; fly_fl->dragrot=1;
        }
        if (state==GLUT_UP) {
            fly_fl->dragrot=0;
        }
    }
}


static void fly_motion(int x,int y)
{
    y=fly_fl->wysize-1-y;
    /* do something with x,y */
    if (fly_fl->dragrot==1 && (x!=fly_fl->mx0 || y!=fly_fl->my0)) {
        /* rotate the camera direction based on the mouse drag motion */
        fly_dragrotsub(fly_fl,(double)fly_fl->mx0,(double)fly_fl->my0,
            (double)x,(double)y);
        fly_fl->mx0=x; fly_fl->my0=y;
    }
}


static void fly_keyboard(unsigned char key,int x,int y)
{
    int wasdigit;
    fly fl;

    fl=fly_fl;
    fl->key=key;
    wasdigit=0;
    switch (key) {
    case 0x1b:
        fl->eventnum=FLY_QUIT; (*fl->event)(fl);
        exit(0);
        break;
    case 'a':
    case 'z':
        /* accelerate forwards/backwards */
        {
            double q,v;

            q=sqrt(sqrt(sqrt(2.0)))-1.0;
            v=q*(fl->velocity>0.0?fl->velocity:-fl->velocity);
            q=0.00001;
            if (v==0.0) v=q;
            if (v<0.02*q) v=0.02*q;
            if (key=='z') v= -v;
            fl->velocity+=v;
            fl->animate_t= -1.0;
        }
        break;
    case ' ':
        /* stop flight motion completely */
        fl->velocity=0.0;
        fl->animate_t= -1.0;
        break;
    case 'f':
        /* keep current mesh for debug inspection */
        fl->freeze=1;
        break;
    case 'F':
        /* go back to usual per-frame view-dependent mesh updates */
        fl->freeze=0;
        break;
    case 'V'-'@': /* ctrl-V */
        /* save viewpoint data to file "viewpoint.txt" */
        {
            int i;
            char name[256];
            FILE *f;

            sprintf(name,"viewpoints/viewpoint%d.txt",fl->digits);
            f=fopen(name,"w");
            if (f==(FILE *)0) {
                fprintf(stderr,"fly: can't write file %s\n",name);
            }else{
                for (i=0;i<12;i++) fprintf(f,"%.17g\n",fl->uvwxyz[i]);
                fclose(f);
            }
        }
        break;
    case 'v':
        /* load viewpoint data from file "viewpointN.txt" */
        /* where N is the set of digits entered on the keyboard */
        {
            int i;
            char name[256];
            FILE *f;

            sprintf(name,"viewpoints/viewpoint%d.txt",fl->digits);
            f=fopen(name,"r");
            if (f==(FILE *)0) {
                fprintf(stderr,"fly: can't read file %s\n",name);
            }else{
                for (i=0;i<12;i++) fscanf(f,"%lf\n",fl->uvwxyz+i);
                fclose(f);
            }
        }
        break;
    case 'V': /* animate transitions between viewpoint{0-9}.txt */

        /* if digits input, set the loop time */
        if (fl->digits!=0) {
            fl->animate_tloop=(double)fl->digits*1e6;
            printf("loop time set to %g seconds\n",fl->animate_tloop/1e6);
        }

        /* convert first 10 viewpoints into smooth interpolating curve */
        fly_generate_loop(fl);

        /* turn on animation, starting at t=0 */
        fl->animate_t0=fly_usec(fl);
        fl->animate_t=0.0;
        fl->loop_framecnt=0;
        fl->loop0=0;
        break;
    case 'l':
    case 'L':
        fly_generate_loop(fl);
        fl->show_loop=(key=='l'?1:0);
        break;
    default:
        if (key>='0' && key<='9') {
            wasdigit=1;
            fl->digits=fl->digits*10+key-'0';
        }else{
            fl->eventnum=FLY_KEY; (*fl->event)(fl);
        }
        break;
    }
    if (!wasdigit) fl->digits=0;
}


static void fly_idle(void)
{
    int v0,v1,i,loop;
    double t,q,dx,dy,dz;
    fly fl;

    fl=fly_fl;

    if (fl->animate_t>-0.01) {
        fl->animate_t=fly_usec(fl)-fl->animate_t0;
        t=(fl->animate_t/fl->animate_tloop)*640.0;
        loop=(int)floor(fl->animate_t/fl->animate_tloop);
        v0=(int)floor(t); q=t-(double)v0;
        v0%=640; v1=(v0+1)%640;
        for (i=0;i<12;i++) {
            fl->uvwxyz[i]=fl->viewtab[v0][i]+
                q*(fl->viewtab[v1][i]-fl->viewtab[v0][i]);
        }
        fly_keyframe_orthogonalize(fl->uvwxyz);
        fl->loop_framecnt++;
        if (loop!=fl->loop0) {
            printf("ave. frames/sec=%g\n",
                (double)fl->loop_framecnt/(fl->animate_tloop/1e6));
            fl->loop0=loop; fl->loop_framecnt=0;
        }
    }else{
        /* fly a little forward in the look direction */
        /* using wall-clock time to interpret velocity */
        t=fl->t0; fl->t0=fly_usec(fl); t=fl->t0-t;
        t/=1e6/70.0; if (t<0.0) t=0.0; if (t>35.0) t=35.0;
        q=fl->velocity*t;
        dx=VX; dy=VY; dz=VZ;
        dx*=q; dy*=q; dz*=q;
        XC+=dx; YC+=dy; ZC+=dz;

        /* clamp the max radius so we don't fly off to infinity */
        {
            double r,rmax;

            rmax=3.0; r=sqrt(XC*XC+YC*YC+ZC*ZC);
            if (r>rmax) { r=rmax/r; XC*=r; YC*=r; ZC*=r; }
        }
    }

    /* show the mesh every idle callback */
    glutPostWindowRedisplay(fl->window);
}


static void fly_drawimage(void)
{
    double vmt[16],vmr[16],vmrt[16],vmp[16],vmprt[16];
    double qx,qy,q,z_near,z_far,qzz,qzw;
    fly fl;

    fl=fly_fl;

    /* enable window */
    glutSetWindow(fl->window);

    /* on first draw call, set up any one-time OpenGL state changes */
    {
        static int firsttime=1;

        if (firsttime) {

            /* set up the gridview texture */
            glGenTextures(1,&fl->gridtex_id);
            glBindTexture(GL_TEXTURE_2D,fl->gridtex_id);
            glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);
            glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);
            glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
            glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
            glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_REPLACE);
            glTexImage2D(GL_TEXTURE_2D,0,GL_RGB,128,128,0,GL_RGBA,
                GL_UNSIGNED_BYTE,(GLvoid *)0);
            glTexSubImage2D(GL_TEXTURE_2D,0,0,0,128,128,
                GL_RGBA,GL_UNSIGNED_BYTE,(GLvoid *)fl->gridtex_raster);

            firsttime=0;
        }
    }

    /* clear and set OpenGL state */
    glClearColor(.15f,.25f,.75f,.00f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);


    /* set up view transform */

    /* window aspect ratio correction factors */
    if (fl->wxsize>fl->wysize)
         { qx=1.0; qy=(double)fl->wxsize/(double)fl->wysize; }
    else { qy=1.0; qx=(double)fl->wysize/(double)fl->wxsize; }

    /* translate */
    vmt[ 0]= 1.0; vmt[ 1]= 0.0; vmt[ 2]= 0.0; vmt[ 3]=0.0;
    vmt[ 4]= 0.0; vmt[ 5]= 1.0; vmt[ 6]= 0.0; vmt[ 7]=0.0;
    vmt[ 8]= 0.0; vmt[ 9]= 0.0; vmt[10]= 1.0; vmt[11]=0.0;
    vmt[12]= -XC; vmt[13]= -YC; vmt[14]= -ZC; vmt[15]=1.0;
    
    /* rotate */
    vmr[ 0]= UX; vmr[ 1]= WX; vmr[ 2]= VX; vmr[ 3]=0.0;
    vmr[ 4]= UY; vmr[ 5]= WY; vmr[ 6]= VY; vmr[ 7]=0.0;
    vmr[ 8]= UZ; vmr[ 9]= WZ; vmr[10]= VZ; vmr[11]=0.0;

    vmr[12]=0.0; vmr[13]=0.0; vmr[14]=0.0; vmr[15]=1.0;
    
    /* perspective */
    q=2.0; /* determines angle of view */
    z_near=0.00003; z_far=4.0;
    qx*=q; qy*=q;
    qzz=(1.0+z_near/z_far)/(1.0-z_near/z_far);
    qzw= -(1.0+qzz)*z_near;
    vmp[ 0]= qx; vmp[ 1]=0.0; vmp[ 2]=0.0; vmp[ 3]=0.0;
    vmp[ 4]=0.0; vmp[ 5]= qy; vmp[ 6]=0.0; vmp[ 7]=0.0;
    vmp[ 8]=0.0; vmp[ 9]=0.0; vmp[10]=qzz; vmp[11]=1.0;
    vmp[12]=0.0; vmp[13]=0.0; vmp[14]=qzw; vmp[15]=0.0;
    
    /* multiply together */
    fly_vm_mul(vmr,vmt,vmrt);
    fly_vm_mul(vmp,vmrt,vmprt);

    /* compute frustum plane-equation coefficients from view transform */
    fly_vm2planes(fl,vmprt);

    /* put result in OpenGL projection transform */
    glMatrixMode(GL_PROJECTION);
    glLoadMatrixd(vmprt);

    /*
     * application draws its 3D scene
     */
    fl->eventnum=FLY_DRAW; (*fl->event)(fl);

    if (fl->show_loop) {
        int i;
        double v[3],d;

        glColor3ub(255,160,0);
        glDisable(GL_TEXTURE_2D);
        glBegin(GL_LINE_LOOP);
        for (i=0;i<640;i++) glVertex3dv(&(fl->viewtab[i][9]));
        glEnd();
        d=0.01;
        glBegin(GL_LINES);
        for (i=0;i<640;i+=64) {
            v[0]=fl->viewtab[i][9];
            v[1]=fl->viewtab[i][10];
            v[2]=fl->viewtab[i][11];
            v[0]-=d; glVertex3dv(v); v[0]+=2.0*d; glVertex3dv(v); v[0]-=d;
            v[1]-=d; glVertex3dv(v); v[1]+=2.0*d; glVertex3dv(v); v[1]-=d;
            v[2]-=d; glVertex3dv(v); v[2]+=2.0*d; glVertex3dv(v); v[2]-=d;
        }
        glEnd();
    }
    

    /* done drawing, so swap buffers and return */
    glutSwapBuffers();
}


/*
 * When not visible, stop animating.  Restart when visible again.
 */

static void fly_visible(int vis)
{
    /* turn animation on/off when window becomes visible/invisible */
    if (vis==GLUT_VISIBLE) {
    }else{
    }
}


static void fly_reshape(int width,int height)
{
    if (fly_fl->wxsize>0) glViewport(0,0,width,height);
    fly_fl->wxsize=width; fly_fl->wysize=height;
    fly_fl->xc=(double)fly_fl->wxsize/2.0;
    fly_fl->yc=(double)fly_fl->wysize/2.0;
    fly_fl->scale=(double)(fly_fl->wxsize+fly_fl->wysize)/4.0;
}


void fly_dragrotsub(fly fl,double x0,double y0,double x1,double y1)
{
    double r,a,ct,st;
    double au,av,aw,ar;
    double bu,bv,bw,br;
    double pu,pv,pw,pr;
    double qu,qv,qw,qr;
    double xu,xv,xw;
    double yu,yv,yw;
    double zu,zv,zw;
    double ax,ay,az;
    double px,py,pz;
    double qx,qy,qz;
    double ax1,ay1,az1;
    double qx1,qy1,qz1;

    /*
     * get unit old and new directions, normal and tangent frame
     */
    r=fl->scale;
    au=(x0-fl->xc)/fl->scale; av= 1.0; aw=(y0-fl->yc)/fl->scale;
    NORM(au,av,aw,ar);
    bu=(x1-fl->xc)/fl->scale; bv= 1.0; bw=(y1-fl->yc)/fl->scale;
    NORM(bu,bv,bw,br);
    CROSS(bu,bv,bw,au,av,aw,pu,pv,pw);
    NORM(pu,pv,pw,pr);
    CROSS(au,av,aw,pu,pv,pw,qu,qv,qw);
    NORM(qu,qv,qw,qr);
    a=acos(au*bu+av*bv+aw*bw);

    /*
     * get world frame in normal/tangent frame
     */
    xu=UX; xv=VX; xw=WX;
    yu=UY; yv=VY; yw=WY;
    zu=UZ; zv=VZ; zw=WZ;
    ax=au*xu+av*xv+aw*xw; px=pu*xu+pv*xv+pw*xw; qx=qu*xu+qv*xv+qw*xw;
    ay=au*yu+av*yv+aw*yw; py=pu*yu+pv*yv+pw*yw; qy=qu*yu+qv*yv+qw*yw;
    az=au*zu+av*zv+aw*zw; pz=pu*zu+pv*zv+pw*zw; qz=qu*zu+qv*zv+qw*zw;

    /*
     * rotate world frame from a to b in aq plane
     */
    ct=cos(a); st=sin(a);
    ax1=ct*ax-st*qx; qx1=st*ax+ct*qx;
    ay1=ct*ay-st*qy; qy1=st*ay+ct*qy;
    az1=ct*az-st*qz; qz1=st*az+ct*qz;
    ax=ax1; qx=qx1;
    ay=ay1; qy=qy1;
    az=az1; qz=qz1;

    /*
     * get world frame back in camera frame
     */
    xu=ax*au+px*pu+qx*qu; xv=ax*av+px*pv+qx*qv; xw=ax*aw+px*pw+qx*qw;
    yu=ay*au+py*pu+qy*qu; yv=ay*av+py*pv+qy*qv; yw=ay*aw+py*pw+qy*qw;
    zu=az*au+pz*pu+qz*qu; zv=az*av+pz*pv+qz*qv; zw=az*aw+pz*pw+qz*qw;

    UX=xu; VX=xv; WX=xw;
    UY=yu; VY=yv; WY=yw;
    UZ=zu; VZ=zv; WZ=zw;

    /* NOTE: should re-orthonormalize every so often... */
}


void fly_vm_mul(double *vma,double *vmb,double *vmab)
{
    int i,j,k;
    double d;

    for (i=0;i<4;i++) {
        for (j=0;j<4;j++) {
            d=0.0; for (k=0;k<4;k++) d+=vma[k*4+i]*vmb[j*4+k];
            vmab[j*4+i]=d;
        }
    }
}


void fly_vm_inv(double *vm,double *vmi)
{
    int i,j,n,imax,j0,pivot[4],pivot1[4];
    double a[4][4],b[4][4],q,qmax;

    /* set the dimension (the routine will work for any n) */
    n=4;

    /* copy source matrix into local copy (the copy will be modified) */
    for (i=0;i<n;i++) {
        for (j=0;j<n;j++) {
            a[i][j]=vm[j*n+i];
            b[i][j]=(i==j?1.0:0.0);
        }
    }

    /* indicate no pivoting has occurred yet */
    for (i=0;i<n;i++) { pivot[i]= -1; pivot1[i]= -1; }

    #define ABS(X) (X<0.0?-X:X)
    
    /* do Gauss eliminations with pivoting    */
    /* (see any good numerical analysis book) */
    for (j0=0;j0<n;j0++) {

        /* find active row with largest abs(a[i][j0]) */
        for (i=0,imax= -1,qmax=0.0;i<n;i++) {
            q=a[i][j0];
            if (pivot[i]<0 && (imax<0 || ABS(q)>ABS(qmax)))
                { imax=i; qmax=q; }
        }
        if (imax<0 || ABS(qmax)<1e-20)
            { fprintf(stderr,"fly_vm_inv: degenerate matrix\n"); exit(1); }
        pivot[imax]=j0; pivot1[j0]=imax;
    
        /* normalize so a[imax][j0]=1.0 */
        q=1.0/qmax; for (j=0;j<n;j++) { a[imax][j]*=q; b[imax][j]*=q; }

        /* zero out a[i][j0] of other rows */
        for (i=0;i<n;i++) {
            if (i!=imax) {
                q=a[i][j0];
                for (j=0;j<n;j++) {
                    a[i][j]-=a[imax][j]*q; b[i][j]-=b[imax][j]*q;
                }
            }
        }
    }

    /* unpermute inverse and store in destination matrix */
    for (i=0;i<n;i++) {
        for (j=0;j<n;j++) {
            vmi[j*n+i]=b[pivot1[i]][j];
        }
    }
}


void fly_vm_apply(double *vm,double *p,double *pr)
{
    int i,j;
    double s,r[4],a[4];

    for (i=0;i<3;i++) a[i]=p[i];
    a[3]=1.0;
    for (i=0;i<4;i++) { s=0.0; for (j=0;j<4;j++) s+=vm[j*4+i]*a[j]; r[i]=s; }
    for (i=0;i<3;i++) pr[i]=r[i]/r[3];
}


void fly_vm2planes(fly fl,double *vm)
{
    int j,k;
    double vmi[16],p[8][3],g[3];

    /* compute inverse of view transform */
    fly_vm_inv(vm,vmi);

    /* send eight frustum corners through inverse transform */
    for (k=0;k<8;k++) {
        for (j=0;j<3;j++) p[k][j]=((k&(1<<j))?1.0:-1.0);
        fly_vm_apply(vmi,p[k],p[k]);
    }

    /* get misc point in the interior of the frustum volume */
    for (j=0;j<3;j++) g[j]=0.5*(p[0][j]+p[7][j]);

    /* compute plane equation coefficients for all six faces */
    fly_pnts2plane(fl,0,p[0],p[1],p[2],g);
    fly_pnts2plane(fl,1,p[0],p[2],p[4],g);
    fly_pnts2plane(fl,2,p[0],p[4],p[1],g);
    fly_pnts2plane(fl,3,p[7],p[6],p[5],g);
    fly_pnts2plane(fl,4,p[7],p[5],p[3],g);
    fly_pnts2plane(fl,5,p[7],p[3],p[6],g);
}


void fly_pnts2plane(fly fl,int i,double *pc,double *pa,double *pb,double *g)
{
    int j;
    double a[3],b[3],c[3],nx,ny,nz,nr;
    float *vh;

    for (j=0;j<3;j++) { a[j]=pa[j]-pc[j]; b[j]=pb[j]-pc[j]; c[j]=pc[j]; }
    CROSS(a[0],a[1],a[2],b[0],b[1],b[2],nx,ny,nz)
    NORM(nx,ny,nz,nr)
    if (nx*(g[0]-c[0])+ny*(g[1]-c[1])+nz*(g[2]-c[2])>0.0)
        { nx= -nx; ny= -ny; nz= -nz; }
    vh=fl->frust_planes[i];
    vh[0]=nx; vh[1]=ny; vh[2]=nz;
    vh[3]= -(nx*c[0]+ny*c[1]+nz*c[2]);
}


void fly_keyframe_orthogonalize(double *kf)
{
    int i,j;
    double q[9],a,b,e,d;

    a=0.25; b=1.0-a;
    for (j=0;j<10;j++) {
        CROSS(kf[0],kf[1],kf[2],kf[3],kf[4],kf[5],q[6],q[7],q[8])
        CROSS(kf[3],kf[4],kf[5],kf[6],kf[7],kf[8],q[0],q[1],q[2])
        CROSS(kf[6],kf[7],kf[8],kf[0],kf[1],kf[2],q[3],q[4],q[5])
        NORM(q[0],q[1],q[2],d)
        NORM(q[3],q[4],q[5],d)
        NORM(q[6],q[7],q[8],d)
        e=0.0;
        for (i=0;i<9;i++) { d=kf[i]-q[i]; e+=d*d; kf[i]=b*kf[i]+a*q[i]; }
        NORM(kf[0],kf[1],kf[2],d)
        NORM(kf[3],kf[4],kf[5],d)
        NORM(kf[6],kf[7],kf[8],d)
    }
    CROSS(kf[0],kf[1],kf[2],kf[3],kf[4],kf[5],kf[6],kf[7],kf[8])
    CROSS(kf[3],kf[4],kf[5],kf[6],kf[7],kf[8],kf[0],kf[1],kf[2])
    CROSS(kf[6],kf[7],kf[8],kf[0],kf[1],kf[2],kf[3],kf[4],kf[5])
    NORM(kf[0],kf[1],kf[2],d)
    NORM(kf[3],kf[4],kf[5],d)
    NORM(kf[6],kf[7],kf[8],d)
}


void fly_generate_loop(fly fl)
{
    int v,i,j,n,n2;
    char name[256];
    double *viewtab,*viewtab2,*v0,*v1,*v2,*v3,*vx;
    FILE *f;

    n=10;
    viewtab=(double *)malloc(n*12*sizeof(double));

    /* load all 10 keyframe viewpoints */
    for (v=0;v<10;v++) {
        sprintf(name,"viewpoints/viewpoint%d.txt",v);
        f=fopen(name,"r");
        if (f==(FILE *)0) {
            fprintf(stderr,"fly: can't read file %s\n",name);
        }else{
            for (i=0;i<12;i++) fscanf(f,"%lf\n",viewtab+(12*v+i));
            fclose(f);
        }
    }

    /* refine smoothly, interpolating; re-orthogonalize each step */
    while (n<640) {
        n2=n*2;
        viewtab2=(double *)malloc(n2*12*sizeof(double));
        for (i=0;i<n;i++) {
            j=((i-1)+n)%n; v0=viewtab+12*j;
            v1=viewtab+12*i;
            j=(i+1)%n; v2=viewtab+12*j;
            j=(i+2)%n; v3=viewtab+12*j;
            vx=viewtab2+12*2*i;
            for (j=0;j<12;j++) vx[j]=v1[j];
            vx=viewtab2+12*(2*i+1);
            for (j=0;j<12;j++)
                { vx[j]=(9.0*(v1[j]+v2[j])-(v0[j]+v3[j]))/16.0; }
            fly_keyframe_orthogonalize(vx);
        }
        free((void *)viewtab);
        viewtab=viewtab2; n=n2;
    }

    /* copy result to fl->viewtab, free remaining temp array */
    for (v=0;v<640;v++) {
        for (i=0;i<12;i++) fl->viewtab[v][i]=viewtab[12*v+i];
    }
    free((void *)viewtab);
}


