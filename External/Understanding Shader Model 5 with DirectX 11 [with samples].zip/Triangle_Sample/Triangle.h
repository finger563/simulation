//--------------------------------------------------------------------------------------
// File: Triangle.h
//
// Sample of DirectX11 Tessellation Tutorial from www.xtunt.com
// @Authors: Gustavo Nunes
//			 Alexandre Valdetaro
//--------------------------------------------------------------------------------------

// Our Triangle vertex
struct VERTEX
{
	float m_vPosition[3];
};

//Our Triangle positioned in world space
const VERTEX g_Triangle[3] = {
    {0.0f,0.0f,0.0f},
	{0.0f,0.0f,10.0f},
	{10.0f,0.0f,10.0f}
};
