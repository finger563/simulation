
/*
 * file.c                                                    lib file support
 * by Mark Duchaineau (free but copyrighted, see LibGen/COPYING)
 *
 * 01-08-94: extracted from lib.c and extended
 * 03-11-94: lib_statinfo()
 * 11-06-99: removed automatic "can't read" message from lib_read()
 *
 */


void lib_init_file(/* */);
void lib_statinfo(/* str ext,int *rtime,int *rsize */);
int lib_isfile(/* str ext */);
str lib_read(/* str ext */);
void lib_delete(/* str ext */);
int lib_filecmp(/* str ext,str buf */);
int lib_openw(/* str ext */);


void lib_init_file()
{
}

void lib_statinfo(ext,rtime,rsize)
str ext; int *rtime; int *rsize;
{
    static struct stat st_store;
    static struct stat *st = &st_store;
    str path;
    int r;

    path=str_concat(libname(),ext);
    r=stat(path,st);
    mem_put(path,"lib_isfile");
    if (r) {
        *rtime=0;
        *rsize=0;
        return;
    }
    *rtime=st->st_mtime;
    *rsize=st->st_size;
}


int lib_isfile(ext)
str ext;
{
    static struct stat st_store;
    static struct stat *st = &st_store;
    str path;
    int r;

    path=str_concat(libname(),ext);
    r=stat(path,st);
    mem_put(path,"lib_isfile");
    return r?0:1;
}

str lib_read(ext)
str ext;
{
    int id,n;
    static struct stat st_store;
    static struct stat *st = &st_store;
    str path,buf;

    path=str_concat(libname(),ext);
    if ((id=open(path,O_RDONLY))<0) {
        /* fprintf(stderr,"lib: can't read %s in %s\n",path,libdir()); */
        mem_put(path,"lib_read"); return (str)0;
    }
    if (fstat(id,st)) {
        fprintf(stderr,"lib: unable to fstat %s in %s\n",path,libdir());
        close(id); mem_put(path,"lib_read"); return (str)0;
    }
    n=st->st_size;
    if (n<8 || n>0x10000000) {
        fprintf(stderr,"lib: bad file size for %s in %s\n",path,libdir());
        close(id); mem_put(path,"lib_read"); return (str)0;
    }
    buf=mem_get(n+1,"lib_read");
    if (read(id,buf,n)!=n) {
        fprintf(stderr,"lib: unable to read %d bytes from %s in %s\n",
            n,path,libdir());
        close(id); mem_put(buf,"lib_read");
        mem_put(path,"lib_read"); return (str)0;
    }
    close(id);
    buf[n]='\0';
    if (verbose) printf("    read %s in %s\n",path,libdir());
    mem_put(path,"lib_read");
    return buf;
}

void lib_delete(ext)
str ext;
{
    str path;

    if (!lib_isfile(ext)) return;
    path=str_concat(libname(),ext);
    printf("deleting %s in %s\n",path,libdir());
    unlink(path);
    mem_put(path,"lib_delete");
}

int lib_filecmp(ext,buf)
str ext; str buf;
{
    int r;
    str buf1;

    buf1=lib_read(ext);
    if (!buf1) return 0;
    r=str_cmp(buf,buf1);
    mem_put(buf1,"lib_filecmp");
    return r;
}

int lib_openw(ext)
str ext;
{
    int id;
    str path;

    lib_delete(ext);
    path=str_concat(libname(),ext);
    if ((id=open(path,O_WRONLY|O_CREAT,0644))<0) {
        fprintf(stderr,"lib: can't create %s in %s\n",path,libdir());
    }else{
        printf("creating %s in %s\n",path,libdir());
    }
    mem_put(path,"lib_openw");
    return id;
}


