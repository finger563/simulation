
/*
 * libpath.c                                            libpath stack support
 * by Mark Duchaineau (free but copyrighted, see LibGen/COPYING)
 *
 * 01-08-94: wrote
 * 03-18-94: fixed pop bug
 * 09-06-01: use of LIBHOME (set externally) instead of LIB_LIBDIR
 *           (which was set during compile time, and could be wrong)
 * 06-27-02: fixed libhome to be actual path for proper path stripping
 *
 */


typedef struct libpath_structdef {
    str dir;                                /* directory path                */
    str name;                               /* file basename                 */
    struct libpath_structdef *lp0,*lp1;     /* list links                    */
} libpath_struct;

typedef libpath_struct *libpath;

void lib_init_libpath();
str libdir();
str libname();
void libpath_pushpath(/* str path */);
void libpath_push(/* str dir,str name */);
void libpath_pop(/* */);
void libpath_setpath(/* str path */);
void libpath_set(/* str dir,str name */);
void libpath_setdir(/* str dir */);
void libpath_setname(/* str name */);
str libpath_getcwd(/* */);

char *libhome;
libpath libpath0,libpath1;


str libdir() { return libpath1?libpath1->dir:"???"; }
str libname() { return libpath1?libpath1->name:"???"; }

void lib_init_libpath()
{
    str current_dir;

    libhome=getenv("LIBHOME");
    if (!libhome) {
        fprintf(stderr,"lib: LIBHOME environment variable must be set\n");
        fprintf(stderr,"     to the directory which contains the Lib\n");
        fprintf(stderr,"     directory (typically this is the path of\n");
        fprintf(stderr,"     LibGen directory, such as /home/mydir/LibGen\n");
        fprintf(stderr,"\n");
        fprintf(stderr,"     Quitting.\n");
        exit(1);
    }

    /* put actual path into libhome for correct path stripping */
    current_dir=libpath_getcwd();
    if (chdir(libhome)) {
        fprintf(stderr,"Bad LIBHOME: can't find directory <%s>\n",libhome);
        exit(1);
    }
    libhome=libpath_getcwd();
    if (chdir(current_dir)) {
        fprintf(stderr,"strange error: can't get back to <%s>\n",current_dir);
        exit(1);
    }
    mem_put(current_dir,"lib_init_libpath");

    libpath0=(libpath)0; libpath1=(libpath)0;
    libpath_push(".","unknown");
}


void libpath_pushpath(path)
str path;
{
    libpath_push(".","unknown");
    libpath_setpath(path);
}

void libpath_push(dir,name)
str dir; str name;
{
    libpath lp;

    lp=(libpath)mem_get(sizeof(libpath_struct),"libpath_create");
    lp->dir=str_dup(""); lp->name=str_dup(name);
    lp->lp0=libpath1; lp->lp1=(libpath)0;
    if (lp->lp0) lp->lp0->lp1=lp; else libpath0=lp;
    if (lp->lp1) lp->lp1->lp0=lp; else libpath1=lp;
    libpath_setdir(dir);
}

void libpath_pop()
{
    libpath lp;

    lp=libpath1;
    if (lp->lp0) lp->lp0->lp1=lp->lp1; else libpath0=lp->lp1;
    if (lp->lp1) lp->lp1->lp0=lp->lp0; else libpath1=lp->lp0;
    mem_put(lp->dir,"libpath_destroy");
    mem_put(lp->name,"libpath_destroy");
    mem_put((char *)lp,"libpath_destroy");
    if (libpath1) libpath_set(libpath1->dir,libpath1->name);
}

void libpath_setpath(path)
str path;
{
    str dir,name,dot;

    name=str_lastof(path,'/');
    dot=str_lastdot(path);
    if (name[0]!='/' || !str_cmp(dot,".l")) {
        dir=str_dup("."); name=path;
    }else{
        dir=str_duplen(path,name-path); name++;
    }
    name=dot[0]?str_duplen(name,dot-name):str_dup(name);
    libpath_set(dir,name);
    mem_put(dir,"libpath_set");
    mem_put(name,"libpath_set");
}

void libpath_set(dir,name)
str dir; str name;
{
    libpath_setdir(dir); libpath_setname(name);
}

void libpath_setdir(dir)
str dir;
{
    libpath lp;

    lp=libpath1;
    /* poor man's directory search--needs to be upgraded */
    if (chdir(dir) && (dir[0]=='/' || (chdir(libhome) || chdir(dir)))) {
        fprintf(stderr,"lib: unable to chdir to %s\n  from %s or %s\n",
            dir,lp->dir,libhome);
        exit(1);
    }
    mem_put(lp->dir,"libpath_setdir");
    lp->dir=libpath_getcwd();
}

void libpath_setname(name)
str name;
{
    str name1;

    name1=str_dup(name);
    mem_put(libpath1->name,"libpath_setname");
    libpath1->name=name1;
}


/*
 * ========== internal stuff ==========
 */

str libpath_getcwd()
{
    int i;
    char dir[1024];

    for (i=0;i<1024;i++) dir[i]='\0';
    if (!getcwd(dir,1022)) {
        fprintf(stderr,"lib: unable to get current directory\n");
        exit(1);
    }
    return str_dup(dir);
}


