
/*
 * chunk.c                                                partial c parser
 * by Mark Duchaineau (free but copyrighted, see LibGen/COPYING)
 *
 * 11-27-92: wrote
 * 03-18-94: C++-style comments (// ...)
 * 03-19-02: added currentfile info to chunk calls/data for error messages
 *
 */


typedef struct chunk_structdef {
    int type;
    char *s;
    int slen;
    struct chunk_structdef *cp,*c0,*c1,*cc0,*cc1;   /* parent, sibs and kids */
} chunk_struct;

typedef chunk_struct *chunk;

void lib_init_chunk();
chunk chunk_create();
void chunk_destroy(/* chunk c */);
chunk chunk_nextnonwhite(/* chunk c */);
void chunk_print(/* chunk c */);
chunk chunkify(/* char *buf */);
int chunk_line(/* char *buf,char *s */);
int chunk_endchar(/* char *s */);
chunk chunk_eat(/* char **rs,int endchar */);

char *chunk_buf,chunk_currentfile[1024];


void lib_init_chunk()
{
}

chunk chunk_create()
{
    chunk c;

    c=(chunk)mem_get(sizeof(chunk_struct),"chunk_create");
    c->type=0;
    c->s=""; c->slen=0;
    c->cp=(chunk)0;
    c->c0=c->c1=(chunk)0;
    c->cc0=c->cc1=(chunk)0;
    return c;
}

void chunk_destroy(c)
chunk c;
{
    chunk cc,cc1;

    for (cc=c->cc0;cc;cc=cc1) {
        cc1=cc->c1;
        chunk_destroy(cc);
    }
    mem_put((char *)c,"chunk_destroy");
}

chunk chunk_nextnonwhite(c)
chunk c;
{
    c=c->c1;
    while (c && (c->type==' ' || c->type=='*')) c=c->c1;
    return c;
}

void chunk_print(c)
chunk c;
{
    int ch;
    char *s,*s1;
    chunk cc;

    if (c->cc0) {
        printf("<{%c>",c->s[0]);
        for (cc=c->cc0;cc;cc=cc->c1) chunk_print(cc);
        printf("<%c}>",c->s[c->slen-1]);
    }else{
        ch=c->type;
        for (s=c->s,s1=s+(c->slen);s<s1;s++) {
            switch (*s) {
            case '\n':
                printf("%c",'\n');
                break;
            case ' ':
                printf("%c",' ');
                break;
            default:
                if (ch>=32 && ch<127) printf("%c",ch);
                else printf("<%d>",ch);
                break;
            }
        }
    }
}

chunk chunkify(buf,currentfile)
char *buf; char *currentfile;
{
    chunk c;

    chunk_buf=buf; sprintf(chunk_currentfile,"%s",currentfile);
    c=chunk_eat(&buf,0);
    return c;
}

int chunk_line(buf,s)
char *buf; char *s;
{
    int n;
    char *b;

    for (b=buf,n=1;*b && b<s;b++) if (*b=='\n') n++;
    return n;
}

int chunk_endchar(s)
char *s;
{
    int endchar,ch0,ch1;

    endchar='+'; ch0=s[0]; ch1=s[0]?s[1]:s[0];
    switch (ch0) {
    case '\0':
        endchar='\0';
        break;
    case '/':
        if (ch1=='*') endchar=ch1;
        if (ch1=='/') endchar=ch1;
        break;
    case '\'':
    case '"':
        endchar=ch0;
        break;
    case ';':
        endchar=';';
        break;
    case ',':
        endchar=',';
        break;
    case '{':
        endchar='}';
        break;
    case '(':
        endchar=')';
        break;
    case '[':
        endchar=']';
        break;
    case '}':
    case ')':
    case ']':
        endchar='.';
        break;
    case ' ':
    case '\n':
    case '\t':
        endchar=' ';
        break;
    case '#':
        endchar='#';
        break;
    default:
        if (is_alpha(ch0)) endchar='a';
        else{
            if (ch0=='0') {
                if (ch1=='x') endchar='x';
                else endchar='0';
            }else{
               if (ch0=='.' && is_num(ch1)) endchar='1';
               else{
                   if (is_num(ch0)) endchar='1';
                   else endchar='+';
               }
            }
        }
        break;
    }
    return(endchar);
}

chunk chunk_eat(rs,endchar)
char **rs; int endchar;
{
    char *s;
    int done,ch;
    chunk c,cc;

    s= *rs;
    if (!*s) return (chunk)0;
    c=chunk_create();
    c->s=s;
    if (endchar) s++;
    if (endchar=='x') s++;
    for (done=0;!done && *s;) {
        ch= *s++;
        switch (endchar) {
        case '\\':
            done=1;
            break;
        case ' ':
        case '+':
            if (chunk_endchar(s-1)!=endchar) { s--; done=1; }
            break;
        case 'a':
            if (!is_alphanum(ch)) { s--; done=1; }
            break;
        case 'x':
            if (!is_hex(ch)) { s--; done=1; }
            break;
        case '*':
            if (ch=='*' && *s=='/') { if (*s) s++; done=1; }
            break;
        case '/':
            if (ch=='\n') { done=1; }
            break;
        case ';':
        case ',':
            s--; done=1;
            break;
        case '0':
            if (!is_oct(ch)) {
                if (ch=='.' || ch=='e' || is_num(ch)) { s--; endchar='1'; }
                else { s--; done=1; }
            }
            break;
        case '1':
            if (!is_num(ch)) {
                if (ch=='.') endchar='2';
                else{
                    if (ch=='e') {
                        if (*s=='+' || *s=='-') s++;
                        endchar='3';
                    }else { s--; done=1; }
                }
            }
            break;
        case '2':
            if (!is_num(ch)) {
                if (ch=='e') {
                    if (*s=='+' || *s=='-') s++;
                    endchar='3';
                }else { s--; done=1; }
            }
            break;
        case '3':
            if (!is_num(ch)) { s--; done=1; }
            break;
        case '\'':
        case '"':
        case '#':
            switch (ch) {
            case '\\':
                if (*s) s++;
                break;
            default:
                if (ch==((endchar=='#')?'\n':endchar)) done=1;
                break;
            }
            break;
        case '}':
        case ')':
        case ']':
        case '\0':
            if (ch==endchar) done=1;
            else{
                s--;
                if ((cc=chunk_eat(&s,chunk_endchar(s)))) {
                    cc->cp=c; cc->c0=c->cc1; cc->c1=(chunk)0;
                    if (cc->c0) cc->c0->c1=cc; else cc->cp->cc0=cc;
                    if (cc->c1) cc->c1->c0=cc; else cc->cp->cc1=cc;
                }
            }
            break;
        default:
            fprintf(stderr,"chunk_eat: bad endchar ``%c'' on line %d\n",
                (char)endchar,chunk_line(chunk_buf,s));
            fprintf(stderr,"    of file %s\n",chunk_currentfile);
            if (endchar=='.')
                fprintf(stderr," **** extra end bracket ****\n");
            
            exit(1);
            break;
        }
    }
    c->type=endchar;
    c->slen=s-c->s;

    *rs=s;
    return c;
}


