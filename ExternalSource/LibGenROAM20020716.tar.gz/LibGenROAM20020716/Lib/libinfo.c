
/*
 * libinfo.c                                                     lib records
 * by Mark Duchaineau (free but copyrighted, see LibGen/COPYING)
 *
 * 01-09-94: wrote
 * 03-11-94: allow for missing lib_init/lib_quit in public modules
 *           keep .ldata instead of copy of .l
 * 03-18-94: reference change detection
 *           minimum load when cleaning
 * 04-21-94: added C++ comment handling to lib_skipwhite()
 * 07-11-96: handle LIB_MAIN_EXTERNAL, TOK_INIT/TOK_QUIT in such
 * 08-20-96: allow relative load paths
 * 06-19-97: fixed run-on comment; added missing prototype
 * 08-01-97: consolidated changes from home here
 * 10-16-99: support for genexec/cleanexec directives
 * 10-20-99: allow empty lib_archive list and end comma
 * 11-06-99: made path prepend print only in verbose mode
 * 09-10-00: fixed several missing first args in chunk_line() calls
 * 09-11-00: added configexec type
 * 03-19-02: added currentfile info to chunk calls/data for error messages
 * 03-24-02: fixed bug in .ldata for multiple-load includes
 *
 */


/*
 * module/include types
 */

#define LIB_UNKNOWN      0
#define LIB_PUBLIC       1
#define LIB_EXECUTABLE   2
#define LIB_ARCHIVE      3
#define LIB_APPLICATION  4
#define LIB_EXTERNAL     5
#define LIB_GENEXEC      6
#define LIB_CLEANEXEC    7
#define LIB_CONFIGEXEC   8
#define LIB_TYPEMAX      8

static char *lib_typestrtab[10] = {
    "unknown",
    "public",
    "executable",
    "archive",
    "application",
    "external",
    "genexec",
    "cleanexec",
    "configexec"
};

/*
 * module states
 */

#define LIB_STATE_PROCESS    0
#define LIB_STATE_DONE       1
#define LIB_STATE_ERROR      2

typedef struct libstruct_structdef {
    str name;                               /* name of lib_struct type       */
    struct lib_structdef *l;                /* module defining the type      */
    struct libstruct_structdef *lsp,*ls0,*ls1; /* AVL list                   */
    int h;                                  /* AVL height                    */
} libstruct_struct;

typedef libstruct_struct *libstruct;

typedef struct libref_structdef {
    int type;                               /* type of this link             */
    str path;                               /* path to referenced module     */
    str load;                               /* load field if needed          */
    struct lib_structdef *l_from,*l_to;     /* lib ref. from and to          */
    struct libref_structdef *lr0,*lr1;      /* links in l_from's libref list */
} libref_struct;

typedef libref_struct *libref;

typedef struct lib_structdef {
    int type;                               /* type of this lib module       */
    int pass;                               /* pass number during processing */
    int state;                              /* see defs above                */
    int l_time,l_size;                      /* current stat on .l file       */
    int iscplusplus;                        /* set if lib_CC in source       */
    int isextmain;                          /* set if lib_main_external      */
    int changed;                            /* set if compile needed         */
    int flag;                               /* flag for various traversals   */
    str dir;                                /* directory                     */
    str name;                               /* base name                     */
    str includepath;                        /* include path (optional)       */
    str load;                               /* load flags (optional)         */
    str buf;                                /* buffer for the .l file        */
    chunk c;                                /* crude parse tree from buf     */
    chunk c_init,c_quit;                    /*   lib_init/quit blocks        */
    struct lib_structdef *l0,*l1;           /* lib links in lib0,...,lib1    */
    libref lr0,lr1;                         /* include links                 */
} lib_struct;

typedef lib_struct *lib;

void lib_init_libinfo(/* */);
void lib_exit(/* */);

void libref_create(/* lib l_from,int type,str path,str load */);
void libref_destroy(/* libref lr */);

lib lib_create(/* str dir, str name */);
void lib_destroy(/* lib l */);
lib lib_find(/* str dir,str name */);
lib lib_load(/* str path */);
void lib_loaddata(/* lib l */);
void lib_loadbuf(/* lib l */);
void lib_scan_load(/* lib l,chunk c */);
void lib_clean(/* lib l */);
chunk lib_getargs(/* lib l,chunk *rc,str types,int tok */);
void lib_skipwhite(/* chunk *rc */);
str lib_typestr(/* int type */);
void printleaf(/* chunk c */);

void libstruct_init(/* */);
libstruct libstruct_find(/* str name */);
void libstruct_add(/* str name,lib l */);
void libstruct_balance(/* libstruct l */);
void libstruct_print(/* libstruct ls,str indent */);

void lib_init_exec();
void lib_execinit(/* str arg */);
void lib_execadd(/* str arg */);
void lib_exec();



libstruct ls_root;
lib lib0,lib1;
int lib_scan_loadgen;


/*
 * module initialization
 */

void lib_init_libinfo()
{
    libstruct_init();
    lib0=(lib)0; lib1=(lib)0;
    lib_scan_loadgen=0;
}

/*
 * exit on error
 */

void lib_exit()
{
    fprintf(stderr,"...exiting lib\n");
    exit(1);
}


/*
 * create a lib reference
 */

void libref_create(l_from,type,path,load)
lib l_from; int type; str path; str load;
{
    libref lr;

    lr=(libref)mem_get(sizeof(libref_struct),"libref_create");
    lr->type=type;
    lr->l_from=l_from;
    lr->l_to=(lib)0;
    lr->path=str_dup(path);
    lr->load=
        (load && load[0] && (load[0]!='-' || load[1]))?str_dup(load):(str)0;
    lr->lr0=lr->l_from->lr1; lr->lr1=(libref)0;
    if (lr->lr0) lr->lr0->lr1=lr; else lr->l_from->lr0=lr;
    if (lr->lr1) lr->lr1->lr0=lr; else lr->l_from->lr1=lr;
    if (type==LIB_CONFIGEXEC && mode==LIB_MODE_GEN) {
        lib_execinit(path); lib_exec();
    }
}

/*
 * destroy a lib reference
 */

void libref_destroy(lr)
libref lr;
{
    if (lr->lr0) lr->lr0->lr1=lr->lr1; else lr->l_from->lr0=lr->lr1;
    if (lr->lr1) lr->lr1->lr0=lr->lr0; else lr->l_from->lr1=lr->lr0;
    mem_put(lr->path,"libref_destroy");
    if (lr->load) mem_put(lr->load,"libref_destroy");
    mem_put((char *)lr,"libref_destroy");
}


/*
 * create a lib record
 */

lib lib_create(dir,name)
str dir; str name;
{
    lib l;

    l=(lib)mem_get(sizeof(lib_struct),"lib_create");
    l->type=LIB_UNKNOWN;
    l->pass=0;
    l->state=LIB_STATE_PROCESS;
    l->l_time= -1;
    l->l_size= -1;
    l->iscplusplus=0;
    l->isextmain=0;
    l->changed=0;
    l->flag=0;
    l->dir=str_dup(dir);
    l->name=str_dup(name);
    l->includepath=(str)0;
    l->load=(str)0;
    l->buf=(str)0;
    l->c=(chunk)0;
    l->c_init=(chunk)0;
    l->c_quit=(chunk)0;
    l->l0=lib1; l->l1=(lib)0;
    if (l->l0) l->l0->l1=l; else lib0=l;
    if (l->l1) l->l1->l0=l; else lib1=l;
    l->lr0=l->lr1=(libref)0;
    return l;
}

/*
 * destroy a lib record
 */

void lib_destroy(l)
lib l;
{
    while (l->lr0) libref_destroy(l->lr0);
    if (l->l0) l->l0->l1=l->l1; else lib0=l->l1;
    if (l->l1) l->l1->l0=l->l0; else lib1=l->l0;
    mem_put(l->dir,"lib_destroy");
    mem_put(l->name,"lib_destroy");
    if (l->includepath) mem_put(l->includepath,"lib_destroy");
    if (l->load) mem_put(l->load,"lib_destroy");
    if (l->buf) mem_put(l->buf,"lib_destroy");
    if (l->c) chunk_destroy(l->c);
    mem_put((char *)l,"lib_destroy");
}

/*
 * search for a lib record
 */

lib lib_find(dir,name)
str dir; str name;
{
    lib l;

    for (l=lib0;l;l=l->l1) {
        if (str_cmp(dir,l->dir) && str_cmp(name,l->name))
            return l;
    }
    return l;
}

/*
 * recursively load lib modules
 */

lib lib_load(path)
str path;
{
    lib l;
    libref lr;

    /*
     * find new directory, push on path stack
     */
    if (verbose) printf("lib_load %s from %s\n",path,libdir());
    libpath_pushpath(path);

    /*
     * return if module already loaded
     */
    l=lib_find(libdir(),libname());
    if (l) {
        if (verbose) printf("(already loaded)\n");
        libpath_pop(); return l;
    }

    /*
     * create new module record
     */
    l=lib_create(libdir(),libname());

    /*
     * return if external module
     */
    if (!str_cmp(str_lastdot(path),".l")) {
        if (verbose) printf("(external module)\n");
        l->type=LIB_EXTERNAL; l->state=LIB_STATE_DONE; libpath_pop(); return l;
    }

    /*
     * get lib data for module
     */
    lib_loaddata(l);

    /*
     * print details if verbose
     */
    if (verbose) {
        for (lr=l->lr0;lr;lr=lr->lr1) printf("  %s include: %s %s\n",
            lib_typestr(lr->type),lr->path,lr->load?lr->load:"-");
        printf("======= total lib_struct AVL =======\n");
        libstruct_print(ls_root,"");
        printf("====================================\n");
    }

    /*
     * recursively load all referenced modules
     */
    for (lr=l->lr0;lr;lr=lr->lr1) {
        if (mode!=LIB_MODE_CLEAN ||
            (lr->type==LIB_ARCHIVE || lr->type==LIB_APPLICATION)) {
            lr->l_to=lib_load(lr->path);
            if (lr->load && lr->l_to && !lr->l_to->load)
                lr->l_to->load=str_dup(lr->load);
        }
    }

    /*
     * pop path stack and return module record
     */
    libpath_pop(); return l;
}

/*
 * get lib data for module
 */

#define LIBDATA_ERROR            0
#define LIBDATA_UNKNOWN         10
#define LIBDATA_PUBLIC          11
#define LIBDATA_EXECUTABLE      12
#define LIBDATA_ARCHIVE         13
#define LIBDATA_APPLICATION     14
#define LIBDATA_EXTERNAL        15
#define LIBDATA_STRUCT          20
#define LIBDATA_TYPE            21
#define LIBDATA_GENEXEC         22
#define LIBDATA_CLEANEXEC       23
#define LIBDATA_CONFIGEXEC      24
#define LIBDATA_MAX             24

int lib_strtodata(s)
str s;
{
    if (str_cmp(s,"unknown"    )) return LIBDATA_UNKNOWN;
    if (str_cmp(s,"public"     )) return LIBDATA_PUBLIC;
    if (str_cmp(s,"executable" )) return LIBDATA_EXECUTABLE;
    if (str_cmp(s,"archive"    )) return LIBDATA_ARCHIVE;
    if (str_cmp(s,"application")) return LIBDATA_APPLICATION;
    if (str_cmp(s,"external"   )) return LIBDATA_EXTERNAL;
    if (str_cmp(s,"struct"     )) return LIBDATA_STRUCT;
    if (str_cmp(s,"type"       )) return LIBDATA_TYPE;
    if (str_cmp(s,"genexec"    )) return LIBDATA_GENEXEC;
    if (str_cmp(s,"cleanexec"  )) return LIBDATA_CLEANEXEC;
    if (str_cmp(s,"configexec" )) return LIBDATA_CONFIGEXEC;
    return LIBDATA_ERROR;
}

int libref_changed(path,timestr,sizestr)
char *path; char *timestr; char *sizestr;
{
    int time0,size0,time1,size1;

    libpath_pushpath(path);
    time0=size0= -1;
    sscanf(timestr,"%d",&time0);
    sscanf(sizestr,"%d",&size0);
    lib_statinfo(".l",&time1,&size1);
    libpath_pop();
    return (time0!=time1 || size0!=size1)?1:0;
}

str getword(rbuf)
str *rbuf;
{
    int i;
    str buf;

    buf= *rbuf;
    while (*buf==' ') buf++;
    for (i=0;buf[i]>' ';i++) ;
    *rbuf=buf+i;
    return str_duplen(buf,i);
}

void lib_loaddata(l)
lib l;
{
    int dirty,time0,size0,time1,size1,doloadgen;
    str data,line,word,word0,word1,word2,word3,word4;

    /*
     * get .l file stat info
     */
    lib_statinfo(".l",&time0,&size0);
    l->l_time=time0; l->l_size=size0;

    /*
     * try getting data from .ldata file
     */
    dirty=0; doloadgen=0;
    data=lib_read(".ldata");
    if (data) {
        for (line=data;*line;) {
            word=line;
            word0=getword(&word); word1=getword(&word); word2=getword(&word);
            word3=getword(&word); word4=getword(&word);
            if (word0[0]=='.') {
                if (mode!=LIB_MODE_CLEAN) {
                    time0=size0= -1;
                    sscanf(word1,"%d",&time0);
                    sscanf(word2,"%d",&size0);
                    lib_statinfo((word0[1]=='x'?"":word0),&time1,&size1);
                    if (time0!=time1 || size0!=size1) dirty=1;
                }
            }else{
                if (!dirty) {
                    switch (lib_strtodata(word0)) {
                    case LIBDATA_UNKNOWN:
                        libref_create(l,LIB_UNKNOWN,word1,word2);
                        break;
                    case LIBDATA_PUBLIC:
                        libref_create(l,LIB_PUBLIC,word1,word2);
                        if (libref_changed(word1,word3,word4)) doloadgen=1;
                        break;
                    case LIBDATA_EXECUTABLE:
                        libref_create(l,LIB_EXECUTABLE,word1,word2);
                        if (libref_changed(word1,word3,word4)) doloadgen=1;
                        break;
                    case LIBDATA_ARCHIVE:
                        libref_create(l,LIB_ARCHIVE,word1,word2);
                        if (libref_changed(word1,word3,word4)) doloadgen=1;
                        break;
                    case LIBDATA_APPLICATION:
                        libref_create(l,LIB_APPLICATION,word1,word2);
                        break;
                    case LIBDATA_EXTERNAL:
                        if (word2) {
                            int i;

                            for (i=0;word2[i];i++)
                                { if (word2[i]=='^') word2[i]=' '; }
                        }
                        libref_create(l,LIB_EXTERNAL,word1,word2);
                        break;
                    case LIBDATA_STRUCT:
                        libstruct_add(word1,l);
                        break;
                    case LIBDATA_TYPE:
                        switch (lib_strtodata(word1)) {
                        case LIBDATA_PUBLIC:     l->type=LIB_PUBLIC;     break;
                        case LIBDATA_EXECUTABLE: l->type=LIB_EXECUTABLE; break;
                        case LIBDATA_ARCHIVE:    l->type=LIB_ARCHIVE;    break;
                        case LIBDATA_APPLICATION: l->type=LIB_APPLICATION;
                                                                         break;
                        case LIBDATA_EXTERNAL:   l->type=LIB_EXTERNAL;   break;
                        default:                 l->type=LIB_UNKNOWN;    break;
                        }
                        break;
                    case LIBDATA_GENEXEC:
                        libref_create(l,LIB_GENEXEC,word1,word2);
                        break;
                    case LIBDATA_CLEANEXEC:
                        libref_create(l,LIB_CLEANEXEC,word1,word2);
                        break;
                    case LIBDATA_CONFIGEXEC:
                        libref_create(l,LIB_CONFIGEXEC,word1,word2);
                        break;
                    default:
                        fprintf(stderr,
                            "*** %s/%s.ldata has incorrect format\n",
                            libdir(),libname());
                        lib_exit();
                        break;
                    }
                }
            }
            mem_put(word0,"lib_loaddata"); mem_put(word1,"lib_loaddata");
            mem_put(word2,"lib_loaddata"); mem_put(word3,"lib_loaddata");
            mem_put(word4,"lib_loaddata");
            while (*line && *line++!='\n') ;
        }
        mem_put(data,"lib_loaddata");
        if (!dirty && !doloadgen) return;
    }

    /*
     * if no .ldata or dirty, load and parse current .l
     */
    if (doloadgen) lib_scan_loadgen=1;
    lib_loadbuf(l);
    if (doloadgen) lib_scan_loadgen=0;
}

void lib_loadbuf(l)
lib l;
{
    char currentfile[1024];

    /*
     * record current .l file name and dir for debug/error messages
     */
    sprintf(currentfile,"%s%s in %s",libname(),".l",libdir());

    /*
     * load buf from .l file
     */
    l->buf=lib_read(".l");
    if (!l->buf) {
        fprintf(stderr,"*** can't read %s\n",currentfile);
        lib_exit();
    }

    /*
     * parse the text
     */
    l->c=chunkify(l->buf,currentfile);
    if (!l->c) {
        fprintf(stderr,"*** can't parse %s\n",currentfile);
        lib_exit();
    }
    /* chunk_print(l->c); */

    /*
     * scan the parse tree to gather load data
     */
    lib_scan_load(l,l->c->cc0);
    if (l->type==LIB_UNKNOWN) {
        fprintf(stderr,
            "*** %s not specified as executable or public\n",
            currentfile);
        lib_exit();
    }
}

/*
 * scan chunk tree for load phase
 */

void lib_scan_load(l,c)
lib l; chunk c;
{
    int i,t;
    chunk c0,c1;
    str path,load,ts1,ts2;

    for (;c;c=c->c1) {
        c0=c;
        switch (t=token(c)) {
        case TOK_ERROR:
            fprintf(stderr,"lib_scan_load: bad lib token in %s at line %d\n",
                l->name,chunk_line(l->buf,c0->s));
            lib_exit();
            break;
        case TOK_LEAF:
            break;
        case TOK_BLOCK:
            lib_scan_load(l,c->cc0);
            break;
        case TOK_INCLUDE:
            c1=lib_getargs(l,&c,"\"\"",TOK_INCLUDE);
            path=str_unquote(c1->cc0->s);
            load=(c1->cc0!=c1->cc1?str_unquote(c1->cc1->s):(str)0);
            /* prepend directory path to relative load path */
            if (load && load[0]!='/' && load[0]!='-') {
                ts1=str_concat(libdir(),"/");
                ts2=str_concat(ts1,load);
                mem_put((char *)ts1,"lib_scan_load");
                mem_put((char *)load,"lib_scan_load");
                load=ts2;
                if (verbose) {
                    printf("\nTOK_INCLUDE load path prepend:\n");
                    printf("  <<<%s>>>\n\n",load);
                }
            }
            if (!lib_scan_loadgen) libref_create(l,
                (str_cmp(str_lastdot(path),".l")?LIB_PUBLIC:LIB_EXTERNAL),
                path,load);
            mem_put(path,"lib_scan_load");
            if (load) mem_put(load,"lib_scan_load");
            break;
        case TOK_INCLUDEPATH:
            c1=lib_getargs(l,&c,"\"",t);
            l->includepath=str_unquote(c1->cc0->s);
            break;
        case TOK_CPLUSPLUS:
            c1=lib_getargs(l,&c,"",t);
            l->iscplusplus=1;
            break;
        case TOK_MAIN_EXTERNAL:
            c1=lib_getargs(l,&c,"",t);
            l->type=LIB_EXECUTABLE; l->isextmain=1;
            break;
        case TOK_MAIN:
            if (!lib_scan_loadgen && l->type!=LIB_UNKNOWN) {
                fprintf(stderr,"lib_scan_load: extra lib_main\n");
                fprintf(stderr,"  in %s at line %d\n",
                    l->name,chunk_line(l->buf,c0->s));
                lib_exit();
            }
            c1=lib_getargs(l,&c,"}",TOK_MAIN);
            l->type=LIB_EXECUTABLE;
            lib_scan_load(l,c1->cc0);
            break;
        case TOK_PUBLIC:
            if (!lib_scan_loadgen && l->type!=LIB_UNKNOWN) {
                fprintf(stderr,"lib_scan_load: extra lib_public\n");
                fprintf(stderr,"  in %s at line %d\n",
                    l->name,chunk_line(l->buf,c0->s));
                lib_exit();
            }
            c1=lib_getargs(l,&c,"}",TOK_PUBLIC);
            l->type=LIB_PUBLIC;
            lib_scan_load(l,c1->cc0);
            break;
        case TOK_INIT:
        case TOK_QUIT:
            if (l->type!=LIB_PUBLIC && l->type!=LIB_ARCHIVE) {
                if (!lib_scan_loadgen && !l->isextmain) {
                    fprintf(stderr,"lib_scan_load: bad usage lib_init/quit\n");
                    fprintf(stderr,"  in %s at line %d\n",
                        l->name,chunk_line(l->buf,c0->s));
                    lib_exit();
                }
                c1=lib_getargs(l,&c,"",t);
            }else{
                c1=lib_getargs(l,&c,"}",t);
                if (t==TOK_INIT) {
                    if (l->c_init) {
                        fprintf(stderr,"lib_scan_load: repeated lib_init\n");
                        fprintf(stderr,"  in %s at line %d\n",
                            l->name,chunk_line(l->buf,c0->s));
                        lib_exit();
                    }
                    l->c_init=c1->cc0;
                }else{
                    if (l->c_quit) {
                        fprintf(stderr,"lib_scan_load: repeated lib_quit\n");
                        fprintf(stderr,"  in %s at line %d\n",
                            l->name,chunk_line(l->buf,c0->s));
                        lib_exit();
                    }
                    l->c_quit=c1->cc0;
                }
                lib_scan_load(l,c1->cc0);
            }
            break;
        case TOK_STRUCT:
            c1=lib_getargs(l,&c,"}a",t);
            path=str_duplen(c1->cc1->s,c1->cc1->slen);
            if (!lib_scan_loadgen) libstruct_add(path,l);
            lib_scan_load(l,c1->cc0);
            mem_put(path,"lib_scan_gen");
            break;
        case TOK_APPLICATION:
            c1=lib_getargs(l,&c,"\"",t);
            path=str_unquote(c1->cc0->s);
            if (!lib_scan_loadgen)
                libref_create(l,LIB_APPLICATION,path,(str)0);
            mem_put(path,"lib_scan_gen");
            break;
        case TOK_ARCHIVE:
            if (!lib_scan_loadgen &&
                l->type!=LIB_PUBLIC && l->type!=LIB_ARCHIVE) {
                fprintf(stderr,"lib_scan_load: nonpublic lib_archive\n");
                fprintf(stderr,"  in %s at line %d\n",
                    l->name,chunk_line(l->buf,c0->s));
                lib_exit();
            }
            c1=lib_getargs(l,&c,"}",t);
            l->type=LIB_ARCHIVE;
            { chunk ca;
                ca=c1->cc0->cc0; if (ca) lib_skipwhite(&ca);
                while (ca) {
                    if (ca->type!='"') {
                        fprintf(stderr,"lib_scan_gen: archive syntax\n");
                        fprintf(stderr,"  expected \"...\"\n");
                        fprintf(stderr,"  in %s at line %d\n",
                            l->name,chunk_line(l->buf,c1->cc0->cc0->s));
                        lib_exit();
                    }
                    path=str_unquote(ca->s);
                    ca=ca->c1;
                    if (ca) lib_skipwhite(&ca);
                    if (ca) {
                        if (ca->type==',') ca=ca->c1;
                        else{
                            fprintf(stderr,"lib_scan_gen: archive syntax\n");
                            fprintf(stderr,"  expected ','\n");
                            fprintf(stderr,"  in %s at line %d\n",
                                l->name,chunk_line(l->buf,ca->s));
                            lib_exit();
                        }
                    }
                    if (ca) lib_skipwhite(&ca);
                    if (!lib_scan_loadgen)
                        libref_create(l,LIB_ARCHIVE,path,(str)0);
                    mem_put(path,"lib_scan_load");
                }
            }
            break;
        case TOK_FUNC:
        case TOK_PROTO:
            c->type=t;
            lib_scan_load(l,c->cc0);
            break;
        case TOK_GENEXEC:
        case TOK_CLEANEXEC:
            c1=lib_getargs(l,&c,"\"",t);
            path=str_unquote(c1->cc0->s);
            i=(t==TOK_GENEXEC?LIB_GENEXEC:LIB_CLEANEXEC);
            if (!lib_scan_loadgen) libref_create(l,i,path,(str)0);
            mem_put(path,"lib_scan_gen");
            break;
        case TOK_CONFIGEXEC:
            c1=lib_getargs(l,&c,"\"",t);
            path=str_unquote(c1->cc0->s);
            i=LIB_CONFIGEXEC;
            if (!lib_scan_loadgen) libref_create(l,i,path,(str)0);
            mem_put(path,"lib_scan_gen");
            break;
        default:
            fprintf(stderr,"lib_scan_load: unknown token\n");
            fprintf(stderr,"  in %s at line %d\n",
                l->name,chunk_line(l->buf,c0->s));
            lib_exit();
            break;
        }
    }
}

/*
 * recursively perform cleaning on modules
 */

void lib_clean(l)
lib l;
{
    libref lr;

    if (l->pass) return;
    l->pass=1;
    libpath_push(l->dir,l->name);
    if (verbose) printf("cleaning up %s in %s\n",libname(),libdir());
    lib_delete(".ldata");
    lib_delete(".c");
    lib_delete(".h");
    lib_delete(".o");
    lib_delete(".a");
    lib_delete("");
    for (lr=l->lr0;lr;lr=lr->lr1) {
        if (lr->l_to && (lr->type==LIB_ARCHIVE || lr->type==LIB_APPLICATION))
            lib_clean(lr->l_to);
    }
    for (lr=l->lr0;lr;lr=lr->lr1) {
        if (lr->type==LIB_CLEANEXEC) { lib_execinit(lr->path); lib_exec(); }
    }
    libpath_pop();
}

/*
 * chunk splicing
 */

void chunk_delete(l,c)
lib l; chunk c;
{
    if (c->c0) c->c0->c1=c->c1;
    else{ if (c->cp) c->cp->cc0=c->c1; else l->c=c->c1; }
    if (c->c1) c->c1->c0=c->c0;
    else{ if (c->cp) c->cp->cc1=c->c0; }
}

void chunk_insert(l,c,cp,c0,c1)
lib l; chunk c; chunk cp; chunk c0; chunk c1;
{
    c->cp=cp; c->c0=c0; c->c1=c1;
    if (c->c0) c->c0->c1=c;
    else{ if (c->cp) c->cp->cc0=c; else l->c=c; }
    if (c->c1) c->c1->c0=c;
    else{ if (c->cp) c->cp->cc1=c; }
}

/*
 * parse chunks into lib directive arguments
 */

chunk lib_getargs(l,rc,types,tok)
lib l; chunk *rc; str types; int tok;
{
    int i;
    chunk c,c0,c1;

    c=c0= *rc;
    c->type=tok;
    c=c->c1;
    for (i=0;c && c->type!=';';c=c1) {
        c1=c->c1;
        c0->slen+=c->slen;
        if (types[i] && c->type==types[i]) {
            chunk_delete(l,c);
            chunk_insert(l,c,c0,c0->cc1,(chunk)0);
            i++;
        }else{
            if (c->type!=' ' && c->type!='*') {
                fprintf(stderr,
                    "lib_getargs %s: syntax error ['%c' vs. '%c']\n",
                    tok_str(tok),c->type,types[i]);
                fprintf(stderr,"    in %s on line %d\n",
                    l->name,chunk_line(l->buf,c0->s));
                lib_exit();
            }
            chunk_delete(l,c); chunk_destroy(c);
        }
    }
    if (types[i] || !c) {
        if (!c || types[i]!='"' || i==0) {
            fprintf(stderr,
                "lib_getargs %s: syntax error [missing ';']\n",tok_str(tok));
            fprintf(stderr,"    in %s on line %d\n",
                l->name,chunk_line(l->buf,c0->s));
            lib_exit();
        }
    }
    *rc=c->c1;
    c0->slen+=c->slen;
    chunk_delete(l,c); chunk_destroy(c);
    return c0;
}

/*
 * misc. helper functions
 */

void lib_skipwhite(rc)
chunk *rc;
{
    chunk c;

    c= *rc;
    while (c && (c->type==' ' || c->type=='*' || c->type=='/')) c=c->c1;
    *rc=c;
}

str lib_typestr(type)
int type;
{
    if (type<0 || type>LIB_TYPEMAX) return "*** lib_typestr: bad index ***";
    return lib_typestrtab[type];
}

void printleaf(c)
chunk c;
{
    char *s,*s1;

    for (s=c->s,s1=s+c->slen;s<s1;s++) printf("%c",*s);
}


/*
 * ========== AVL lib_struct list ==========
 */

void libstruct_init()
{
    ls_root=(libstruct)0;
}

libstruct libstruct_find(name)
str name;
{
    libstruct ls;

    for (ls=ls_root;ls;) {
        switch (str_scmp(name,ls->name)) {
        case -1: ls=ls->ls0; break;
        case  0: return ls;  break;
        case  1: ls=ls->ls1; break;
        default: break;
        }
    }
    return ls;
}

void libstruct_add(name,l)
str name; lib l;
{
    int done;
    libstruct lsp,ls;

    ls=(libstruct)mem_get(sizeof(libstruct_struct),"libstruct_add");
    ls->name=str_dup(name); ls->l=l;
    ls->lsp=(libstruct)0; ls->ls0=(libstruct)0; ls->ls1=(libstruct)0;
    ls->h=0;
    if (!ls_root) { ls_root=ls; return; }
    for (lsp=ls_root,done=0;!done;) {
        switch (str_scmp(name,lsp->name)) {
        case -1:
            if (lsp->ls0) lsp=lsp->ls0; else { done=1; lsp->ls0=ls; }
            break;
        case 1:
            if (lsp->ls1) lsp=lsp->ls1; else { done=1; lsp->ls1=ls; }
            break;
        default:
            fprintf(stderr,"lib_struct %s: repeated in %s\n",name,l->name);
            lib_exit();
            break;
        }
    }
    ls->lsp=lsp; ls->ls0=(libstruct)0; ls->ls1=(libstruct)0;
    libstruct_balance(ls);
}

#define LHT(L) (L?L->h:0)
#define LHTFIX(L) { h0=LHT(L->ls0); h1=LHT(L->ls1); L->h=1+(h1>h0?h1:h0); }

void libstruct_balance(l)
libstruct l;
{
    int h0,h1;
    libstruct lp,la,lb,lc,ld,le;

    lp=l->lsp;
    h0=LHT(l->ls0); h1=LHT(l->ls1);
    if (h1>h0) {
        if (h1-h0>1) {
            if (h1==1+LHT(l->ls1->ls0)) {
                la=l; le=la->ls1; lc=le->ls0; lb=lc->ls0; ld=lc->ls1;
                if (lp) { if (lp->ls0==l) lp->ls0=lc; else lp->ls1=lc; }
                else ls_root=lc;
                lc->lsp=lp;
                lc->ls0=la; la->lsp=lc;
                lc->ls1=le; le->lsp=lc;
                la->ls1=lb; if (lb) lb->lsp=la;
                le->ls0=ld; if (ld) ld->lsp=le;
                LHTFIX(la); LHTFIX(le); LHTFIX(lc);
            }else{
                la=l; lc=la->ls1; lb=lc->ls0;
                if (lp) { if (lp->ls0==l) lp->ls0=lc; else lp->ls1=lc; }
                else ls_root=lc;
                lc->lsp=lp;
                lc->ls0=la; la->lsp=lc;
                la->ls1=lb; if (lb) lb->lsp=la;
                LHTFIX(la); LHTFIX(lc);
            }
        }else l->h=h1+1;
    }else{
        if (h0-h1>1) {
            if (h0==1+LHT(l->ls0->ls1)) {
                la=l; le=la->ls0; lc=le->ls1; lb=lc->ls1; ld=lc->ls0;
                if (lp) { if (lp->ls0==l) lp->ls0=lc; else lp->ls1=lc; }
                else ls_root=lc;
                lc->lsp=lp;
                lc->ls1=la; la->lsp=lc;
                lc->ls0=le; le->lsp=lc;
                la->ls0=lb; if (lb) lb->lsp=la;
                le->ls1=ld; if (ld) ld->lsp=le;
                LHTFIX(la); LHTFIX(le); LHTFIX(lc);
            }else{
                la=l; lc=la->ls0; lb=lc->ls1;
                if (lp) { if (lp->ls0==l) lp->ls0=lc; else lp->ls1=lc; }
                else ls_root=lc;
                lc->lsp=lp;
                lc->ls1=la; la->lsp=lc;
                la->ls0=lb; if (lb) lb->lsp=la;
                LHTFIX(la); LHTFIX(lc);
            }
        }else l->h=h0+1;
    }
    if (lp) libstruct_balance(lp);
}

void libstruct_print(ls,indent)
libstruct ls; str indent;
{
    str indent1;

    if (!ls) return;
    indent1=str_concat(indent,"|");
    libstruct_print(ls->ls0,indent1);
    printf("%s%s\n",indent,ls->name);
    libstruct_print(ls->ls1,indent1);
    mem_put(indent1,"libstruct_print");
}


