
/**
 ** mem.c                                        lib's processed copy of mem.l
 ** by Mark Duchaineau (free but copyrighted, see LibGen/COPYING)
 **
 ** created 12-21-93
 ** 09-17-98: put #ifdef's around sbrk declaration to solve AIX problem
 **
 **/

#ifndef LIB_mem__HERE

#define LIB_mem__HERE 1


/********** /usr/home/duchaine/Sys/Mem/mem.h created by lib **********/


void lib_init_mem();

void lib_quit_mem();


    /* lib_include: */
/*** #include "Sys/sys.h" ***/


    
#define MEM_INUSE     0x00000000
    
#define MEM_FREE      0x20000000
    
#define MEM_GAP       0x40000000
    
#define MEM_TYPE      0xe0000000

    

/*
 * lib_struct mem
 */

typedef struct mem_structdef {
        int size;                         /* requested size in bytes         */
        char *comment;                    /* get/put comments                */
        int skip0;                        /* 8-byte skip back (plus type)    */
        int skip1;                        /* 8-byte skip forward             */
        struct mem_structdef (*mp),(*m0),(*m1);                     /* AVL free list                   */
        int h;                            /* AVL height                      */
    } mem_struct;

typedef mem_struct *mem;



    char *mem_get(/* int size,char *comment */);
    void mem_put(/* char *s,char *comment */);
    int mem_use();
    int mem_free();
    int mem_size(/* char *s */);
    void mem_printinfo(/* char *s */);
    void mem_printfree();
    void mem_check(/* char *s */);


#endif



/********** /usr/home/duchaine/Sys/Mem/mem.c created by lib **********/

 
/*
 * mem.l                                                 memory manager
 * by Mark Duchaineau
 *
 * 11-09-93: wrote clean version from scratch
 * 11-22-93: mem_free()
 * 12-09-93: enclosed in sys.l
 *
 */



/* lib_public include: */
/*** #include "Sys/Mem/mem.h" ***/




/* lib_application "Sys/Mem/Memtest/memtest.l" */



#define MEM_SIZE 4                        /* num. of 8-byte units when FREE  */
#define MEM_BASE 2                        /* num. of 8-byte units when INUSE */
#define MEM_CHARBASE 16                   /* num. of bytes when INUSE        */

mem mem0;                                 /* first mem                       */
mem mem1;                                 /* last mem                        */
mem memfree;                              /* root of AVL list                */
int memfreebytes;                         /* bytes of free mem               */

char *mem_break(/* int size */);
mem mem_findfree(/* int minsize */);
void mem_putfree(/* mem m */);
void mem_getfree(/* mem m */);
void mem_balancefree(/* mem m */);
void mem_printavl(/* mem m,char *inddent */);




/*
 * lib_init for mem
 */

void lib_init_mem()
{

    mem0=(mem)mem_break(0x2000);
    mem1=(mem)((char *)mem0+(0x2000-MEM_CHARBASE));
    memfree=(mem)0;

    mem0->size=0;
    mem0->comment="lib_init 1";
    mem0->skip0=MEM_INUSE;
    mem0->skip1=(0x2000-MEM_CHARBASE)>>3;

    mem1->size=0;
    mem1->comment="lib_init 2";
    mem1->skip0=MEM_GAP|mem0->skip1;
    mem1->skip1=MEM_BASE;

    memfreebytes=0;
    mem_putfree(mem0);

}





/*
 * lib_quit for mem
 */

void lib_quit_mem()
{
 
}




/*
 * get size bytes of memory
 */

char *mem_get(size,comment)
int size; char *comment;
{
    int minsize;
    mem m;

    minsize=(size>>3)+((size&7)?1:0)+MEM_BASE;
    if (minsize<MEM_SIZE) minsize=MEM_SIZE;

    /*
     * get big enough free mem
     */

    if (!(m=mem_findfree(minsize))) {
        int size,gap;

        /*
         * get more from system
         */
        size=minsize<<3;
        size=(size&~0xfff)+((size&0xfff)?0x2000:0x1000);
        m=(mem)mem_break(size);

        /*
         * join mem1 to m with possible gap
         * reserve mem1 record for next gap/join
         */
        gap=(int)m-(int)mem1;
        if ((mem1->skip1=(gap>>3))==MEM_BASE) {
            mem m0;

            mem1->skip0=MEM_INUSE|(mem1->skip0&~MEM_TYPE);
            mem1->skip1=size>>3;
            m=mem1;
            m0=(mem)((char *)m-((m->skip0&~MEM_TYPE)<<3));
            if ((m0->skip0&MEM_TYPE)==MEM_FREE) {
                mem_getfree(m0);
                m0->skip1=m0->skip1+m->skip1; m=m0;
            }
        }else{
            m->skip0=MEM_INUSE|(gap>>3);
            m->skip1=(size>>3)-MEM_BASE;
        }
        mem1=(mem)((char *)m+(m->skip1<<3));
        mem1->comment="mem_get";
        mem1->skip0=MEM_GAP|m->skip1;
        mem1->skip1=MEM_BASE;
        m->size=0; m->comment="mem_get";
    }else mem_getfree(m);

    /*
     * split if too big
     */

    {
        int extra;
        mem m1,m2;

        extra=m->skip1-minsize;
        if (extra>MEM_SIZE+4) {
            m1=(mem)((char *)m+(minsize<<3));
            m2=(mem)((char *)m+(m->skip1<<3));
            m->skip1=minsize;
            m2->skip0=(m2->skip0&MEM_TYPE)|extra;
            m1->size=0; m1->comment="mem_get";
            m1->skip0=MEM_INUSE|minsize;
            m1->skip1=extra;
            mem_putfree(m1);
        }
    }

    /*
     * clean up and return bytes
     */

    m->size=size;
    m->comment=comment;
    { register int *s,*e;

        for (s=(int *)((char *)m+MEM_CHARBASE),
            e=(int *)((char *)m+(m->skip1<<3));s<e;) *s++ =0;
    }
    return (char *)m+MEM_CHARBASE;
}

/*
 * free up memory
 */

void mem_put(s,comment)
char *s; char *comment;
{
    mem m;

    /*
     * get mem associated with s
     * check for correctness
     */
/***
    if (((int)s&7) || s<(char *)mem0+MEM_CHARBASE ||
        s>=(char *)mem1) {
        fprintf(stderr,"mem_put: incorrect pointer by ``%s''\n",
            comment);
        exit(1);
    }
***/
    m=(mem)(s-MEM_CHARBASE);
/***
    if ((m->skip0&MEM_TYPE)!=MEM_INUSE) {
        fprintf(stderr,"mem_put: last accessed by ``%s''\n",m->comment);
        fprintf(stderr,"mem_put: type=%x (repeat put?) by ``%s''\n",
            m->skip0&MEM_TYPE,comment);
        exit(1);
    }
***/

    /*
     * consolidate with free neighbors
     */
    { mem m0,m1;
        m0=(mem)((char *)m-((m->skip0&~MEM_TYPE)<<3));
        m1=(mem)((char *)m+(m->skip1<<3));
        if (m0!=m && ((m0->skip0&MEM_TYPE)==MEM_FREE)) {
            mem_getfree(m0);
            m0->skip1=m0->skip1+m->skip1;
            m1->skip0=(m1->skip0&MEM_TYPE)|m0->skip1;
            m=m0;
        }
        if ((m1->skip0&MEM_TYPE)==MEM_FREE) {
            mem_getfree(m1);
            m->skip1=m->skip1+m1->skip1;
            m1=(mem)((char *)m+(m->skip1<<3));
            m1->skip0=(m1->skip0&MEM_TYPE)|m->skip1;
        }
    }

    /*
     * add to free list
     */
    m->size=0; m->comment=comment;
    mem_putfree(m);
}

/*
 * return total memory space used
 */

int mem_use()
{
    return (int)((char *)mem1-(char *)mem0);
}

/*
 * return total free space used
 */

int mem_free()
{
    return memfreebytes;
}

/*
 * return size of allocated memory
 */

int mem_size(s)
char *s;
{
    mem m;

    m=(mem)(s-MEM_CHARBASE);
    return m->size;
}

/*
 * print out memory map
 */

void mem_printinfo(s)
char *s;
{
    int k;
    char c,*space;
    mem m;

    printf("=================== mem map ====================\n");
    printf("         |        |                             \n");
    printf(" Address:|Size Bar|Caller Notations             \n");
    printf(" (hex)   |X in use|                             \n");
    printf("         |- free  |                             \n");
    printf("         |. alien |                             \n");
    printf("--------- -------- -----------------------------\n");
    space="       ";
    for (m=mem0;m<=mem1;m=(mem)((char *)m+(m->skip1<<3))) {
        switch (m->skip0&MEM_TYPE) {
        case MEM_INUSE:
            c='X';
            break;
        case MEM_FREE:
            c='-';
            break;
        case MEM_GAP:
            c='.';
            break;
        default:
            c='0'+((m->skip0&MEM_TYPE)>>29);
            break;
        }
        printf("%8.8x: %c",(int)m,(char)c);
        for (k=0;(1<<k)<m->skip1;k++) printf("%c",(char)c);
        printf("%s",space+(k>6?6:k)); fflush(stdout);
        printf(" ``%s''",(int)m->comment>0x10000?m->comment:"<error>");
        printf("\n"); fflush(stdout);
    }
    printf("================== AVL free list ===============\n");
    printf("                                                \n");
    mem_printfree();
    printf("                                                \n");
    printf("================================================\n");
}

/*
 * print out free memory AVL tree
 */

void mem_printfree()
{
    if (!memfree) { printf("---no free mem---\n"); return; }
    mem_printavl(memfree,"  ");
}

/*
 * check the integrity of memory list
 */

void mem_check(s)
char *s;
{
    mem m,mp;

    for (m=mem0;m<=mem1;m=(mem)((char *)m+(m->skip1<<3))) {
        if ((int)m->comment<0x10000) {
            fprintf(stderr,"mem_check failed: ``%s'' for m=%p\n",s,m);
            exit(1);
        }
        if ((m->skip0&MEM_TYPE)==MEM_FREE) {
            for (mp=m;mp;mp=mp->mp) {
                if (mp->mp) {
                    if (((mp->mp->m0==mp?1:0)+(mp->mp->m1==mp?1:0))!=1) {
                        fprintf(stderr,"check: bad parent``%s''\n",s);
                        exit(1);
                    }
                }else{
                    if (memfree!=mp) {
                        fprintf(stderr,"check: root not memfree ``%s''\n",s);
                        exit(1);
                    }
                }
            }
        }
    }
}


/*
 * ========== internal stuff ==========
 */

#define BRK(SIZE) {                                                           \
    s=sbrk(SIZE);                                                             \
    if (s==(char *)0 || s==(char *)(-1))                                      \
        { fprintf(stderr,"mem_break: sbrk() failed\n"); exit(1); }            \
}

/*
 * obtain aligned bytes from the system
 */

char *mem_break(size)
int size;
{
    char *s;

    BRK(0);
    if ((int)s&7) {
        BRK(8-((int)s&7));
    }
    BRK(size);
    if ((int)s&7)
        { fprintf(stderr,"mem_break: can't align sbrk()\n"); exit(1); }
    return s;
}

/*
 * find big enough free mem
 * returns 0 if none
 */

mem mem_findfree(minsize)
int minsize;
{
    mem m,mf;

    for (m=memfree,mf=(mem)0;m;) {
        if (m->skip1<minsize) m=m->m1; else { mf=m; m=m->m0; }
    }
    return mf;
}

/*
 * put inuse mem into free list
 */

void mem_putfree(m)
mem m;
{
    int done;
    mem mp;

    memfreebytes+=m->skip1<<3;
    if ((m->skip0&MEM_TYPE)!=MEM_INUSE)
        { fprintf(stderr,"mem_putfree: not INUSE\n"); exit(1); }
    m->skip0=(m->skip0&~MEM_TYPE)|MEM_FREE;
    if (memfree) {
        for (mp=memfree,done=0;!done;) {
            if (m->skip1<mp->skip1) {
                if (mp->m0) mp=mp->m0;
                else { done=1; mp->m0=m; }
            }else{
                if (mp->m1) mp=mp->m1;
                else { done=1; mp->m1=m; }
            }
        }
    }else{ mp=(mem)0; memfree=m; }
    m->mp=mp;
    m->m0=(mem)0;
    m->m1=(mem)0;
    mem_balancefree(m);
}

/*
 * take out free mem to inuse
 */

void mem_getfree(m)
mem m;
{
    mem m1,mp;

    memfreebytes-=m->skip1<<3;
    if ((m->skip0&MEM_TYPE)!=MEM_FREE)
        { fprintf(stderr,"mem_getfree: not FREE\n"); exit(1); }
    m->skip0=(m->skip0&~MEM_TYPE)|MEM_INUSE;
    if ((m1=m->m1)) {
        if (m1->m0) {
            while (m1->m0) m1=m1->m0;
            mp=m1->mp;
            mp->m0=m1->m1;
            if (m1->m1) { m1->m1->mp=mp; mp=m1->m1; }
            m1->m1=m->m1; if (m->m1) m->m1->mp=m1;
        }else mp=m1;
        m1->mp=m->mp;
        if (m->mp) {
            if (m->mp->m0==m) m->mp->m0=m1; else m->mp->m1=m1;
        }else memfree=m1;
        m1->m0=m->m0; if (m->m0) m->m0->mp=m1;
        mem_balancefree(mp);
    }else{
        if (m->m0) m->m0->mp=m->mp;
        if (m->mp) {
            if (m->mp->m0==m) m->mp->m0=m->m0; else m->mp->m1=m->m0;
            mem_balancefree(m->mp);
        }else memfree=m->m0;
    }
}

/*
 * balance the free list using AVL tricks
 */

#define HT(M) (M?M->h:0)
#define HTFIX(M) { h0=HT(M->m0); h1=HT(M->m1); M->h=1+(h1>h0?h1:h0); }

void mem_balancefree(m)
mem m;
{
    int h0,h1;
    mem mp,ma,mb,mc,md,me;

    mp=m->mp;
    h0=HT(m->m0); h1=HT(m->m1);
    if (h1>h0) {
        if (h1-h0>1) {
            if (h1==1+HT(m->m1->m0)) {
                ma=m; me=ma->m1; mc=me->m0; mb=mc->m0; md=mc->m1;
                if (mp) { if (mp->m0==m) mp->m0=mc; else mp->m1=mc; }
                else memfree=mc;
                mc->mp=mp;
                mc->m0=ma; ma->mp=mc;
                mc->m1=me; me->mp=mc;
                ma->m1=mb; if (mb) mb->mp=ma;
                me->m0=md; if (md) md->mp=me;
                HTFIX(ma); HTFIX(me); HTFIX(mc);
            }else{
                ma=m; mc=ma->m1; mb=mc->m0;
                if (mp) { if (mp->m0==m) mp->m0=mc; else mp->m1=mc; }
                else memfree=mc;
                mc->mp=mp;
                mc->m0=ma; ma->mp=mc;
                ma->m1=mb; if (mb) mb->mp=ma;
                HTFIX(ma); HTFIX(mc);
            }
        }else m->h=h1+1;
    }else{
        if (h0-h1>1) {
            if (h0==1+HT(m->m0->m1)) {
                ma=m; me=ma->m0; mc=me->m1; mb=mc->m1; md=mc->m0;
                if (mp) { if (mp->m0==m) mp->m0=mc; else mp->m1=mc; }
                else memfree=mc;
                mc->mp=mp;
                mc->m1=ma; ma->mp=mc;
                mc->m0=me; me->mp=mc;
                ma->m0=mb; if (mb) mb->mp=ma;
                me->m1=md; if (md) md->mp=me;
                HTFIX(ma); HTFIX(me); HTFIX(mc);
            }else{
                ma=m; mc=ma->m0; mb=mc->m1;
                if (mp) { if (mp->m0==m) mp->m0=mc; else mp->m1=mc; }
                else memfree=mc;
                mc->mp=mp;
                mc->m1=ma; ma->mp=mc;
                ma->m0=mb; if (mb) mb->mp=ma;
                HTFIX(ma); HTFIX(mc);
            }
        }else m->h=h0+1;
    }
    if (mp) mem_balancefree(mp);
}

void mem_printavl(m,indent)
mem m; char *indent;
{
    char indent2[256];

    sprintf(indent2,"%s| ",indent);
    if (m->m0) mem_printavl(m->m0,indent2);
    printf("%s%p: skip1=%d h=%d mp=%p m0=%p m1=%p\n",
        indent,m,m->skip1,m->h,m->mp,m->m0,m->m1);
    if (m->m1) mem_printavl(m->m1,indent2);
}


