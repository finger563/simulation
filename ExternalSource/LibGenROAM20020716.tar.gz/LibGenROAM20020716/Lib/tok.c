
/*
 * tok.c                                           token processing for lib
 * by Mark Duchaineau (free but copyrighted, see LibGen/COPYING)
 *
 * 12-23-93: extracted from old lib.c
 * 01-07-94: added tok_str()
 * 05-01-94: added tok_iswhite() test
 * 07-11-96: TOK_MAIN_EXTERNAL, TOK_INCLUDEPATH
 * 10-15-99: added TOK_GENEXEC, TOK_CLEANEXEC
 * 09-11-00: added TOK_CONFIGEXEC
 *
 */


#define TOKMIN            129
#define TOK_ERROR         129
#define TOK_LEAF          130
#define TOK_BLOCK         131
#define TOK_INCLUDE       132
#define TOK_CPLUSPLUS     133
#define TOK_MAIN          134
#define TOK_PUBLIC        135
#define TOK_INIT          136
#define TOK_QUIT          137
#define TOK_STRUCT        138
#define TOK_APPLICATION   139
#define TOK_ARCHIVE       140
#define TOK_FUNC          141
#define TOK_PROTO         142
#define TOK_MAIN_EXTERNAL 143
#define TOK_INCLUDEPATH   144
#define TOK_GENEXEC       145
#define TOK_CLEANEXEC     146
#define TOK_CONFIGEXEC    147
#define TOKMAX            147

static char *tok_strtab[50] = {
    "TOK_ERROR",
    "TOK_LEAF",
    "TOK_BLOCK",
    "TOK_INCLUDE",
    "TOK_CPLUSPLUS",
    "TOK_MAIN",
    "TOK_PUBLIC",
    "TOK_INIT",
    "TOK_QUIT",
    "TOK_STRUCT",
    "TOK_APPLICATION",
    "TOK_ARCHIVE",
    "TOK_FUNC",
    "TOK_PROTO",
    "TOK_MAIN_EXTERNAL",
    "TOK_INCLUDEPATH",
    "TOK_GENEXEC",
    "TOK_CLEANEXEC",
    "TOK_CONFIGEXEC"
};


void lib_init_tok()
{
}

char *tok_str(t)
int t;
{
    if (t<TOKMIN || t>TOKMAX) return "unknown token";
    return tok_strtab[t-TOKMIN];
}


int tok_cmp(s,s1,t)
char *s,*s1,*t;
{
    for (;s<s1 && *s == *t && *t;s++,t++) ;
    return !*t && s==s1;
}

int tok_iswhite(c)
chunk c;
{
    return (c->type==' ' || c->type=='*' || c->type=='/')?1:0;
}

chunk tok_skipwhite(c)
chunk c;
{
    while (c && tok_iswhite(c)) c=c->c1;
    return c;
}

int tok_chunk(c)
chunk c;
{
    chunk cn;

    if (c->type>=128) return c->type;
    if ((!c->cp || !c->cp->type ||
        (c->cp->type=='}' && c->cp->cp && c->cp->cp->type==TOK_PUBLIC)) &&
        c->type==')' && tok_skipwhite(c->cc0) && (cn=chunk_nextnonwhite(c))) {
        if (cn->type=='}') return TOK_FUNC;
        if (cn->type==';') return TOK_PROTO;
    }
    if (c->cc0) return TOK_BLOCK;
    return TOK_LEAF;
}


int token(c)
chunk c;
{
    char *s,*s0,*s1;

    if (c->type!='a') return tok_chunk(c);
    s0=c->s; s1=s0+c->slen;
    s=s0;
    if (c->slen<4) return tok_chunk(c);
    if (*s++ !='l') return tok_chunk(c);
    if (*s++ !='i') return tok_chunk(c);
    if (*s++ !='b') return tok_chunk(c);
    /* 9-21-99: if (*s++ !='_') return TOK_ERROR; */
    if (*s++ !='_') return tok_chunk(c);

    if (tok_cmp(s,s1,"include"      )) return TOK_INCLUDE;
    if (tok_cmp(s,s1,"CC"           )) return TOK_CPLUSPLUS;
    if (tok_cmp(s,s1,"main"         )) return TOK_MAIN;
    if (tok_cmp(s,s1,"public"       )) return TOK_PUBLIC;
    if (tok_cmp(s,s1,"init"         )) return TOK_INIT;
    if (tok_cmp(s,s1,"quit"         )) return TOK_QUIT;
    if (tok_cmp(s,s1,"struct"       )) return TOK_STRUCT;
    if (tok_cmp(s,s1,"application"  )) return TOK_APPLICATION;
    if (tok_cmp(s,s1,"archive"      )) return TOK_ARCHIVE;
    if (tok_cmp(s,s1,"main_external")) return TOK_MAIN_EXTERNAL;
    if (tok_cmp(s,s1,"includepath"  )) return TOK_INCLUDEPATH;
    if (tok_cmp(s,s1,"genexec"      )) return TOK_GENEXEC;
    if (tok_cmp(s,s1,"cleanexec"    )) return TOK_CLEANEXEC;
    if (tok_cmp(s,s1,"configexec"   )) return TOK_CONFIGEXEC;

    return TOK_ERROR;
}


