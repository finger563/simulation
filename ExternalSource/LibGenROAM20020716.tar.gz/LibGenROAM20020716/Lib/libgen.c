
/*
 * libgen.c                                  support for gen processing
 * by Mark Duchaineau (free but copyrighted, see LibGen/COPYING)
 *
 * 01-10-94: wrote
 * 03-11-94: allow for missing lib_init/lib_quit in public modules
 *           keep .ldata instead of copy of .l
 * 03-18-94: cleaning bugs  (see lib.c)
 * 04-20-94: fixing archive .h include ordering
 * 06-04-94: two-phase .h includes (TYPE, HERE)
 * 07-29-95: eliminated useless typedef before .._structdef..
 * 07-11-96: support for lib_main_external with lib_init/lib_quit
 *           lib_includepath
 * 08-01-97: consolidated updates from home source here
 * 09-17-98: updated signal handling for AIX
 * 10-05-98: changed "exec_argv" to "ex_argv" to avoid AIX name conflict
 * 09-21-99: added global generation of lib{argc,argv,envp}
 * 10-16-99: support for genexec/cleanexec directives
 * 10-20-99: allow empty lib_archive list and end comma
 * 10-21-99: moved GENEXEC activity to start of .a phase
 * 11-17-99: moved GENEXEC activity to start of executables phase
 * 12-08-99: added new lib_gen() phase for GENEXEC activity
 * 01-19-00: explicit exit(0) after all lib_quit's (needed for Linux csh -e)
 * 09-11-00: added CONFIGEXEC support for external configure calls before
 *           lib .o compiles
 * 03-24-02: fixed bug in .ldata for multiple-load includes; moved configexec
 *           earlier to its reference creation during load
 * 05-21-02: stripped LIBHOME prefix from absolute paths, since -I<LIBHOME>
 *           is always used (this makes the lib-generated source more
 *           like conventional .h/.c/Makefile  source)
 * 06-07-02: added space before comment termination (to avoid oddities
 *           in converting C++ style comments to old C style)
 * 06-28-02: neutered the C-style comment start inside a C++ comment to /-
 *
 */


void lib_init_libgen();
void libgen_exit(/* */);
int lib_islibstruct(/* chunk c */);
void lib_init_strlist();
void strlist_init();
void strlist_add(/* str s */);
void lib_gen(/* lib l */);
void lib_genx(/* lib l,int pass */);
void lib_changecheck(/* lib l */);
void lib_ar(/* lib l */);
void lib_ccexec(/* lib l,int inarchive */);
void lib_includepaths(/* lib l */);
void lib_scan_gen(/* lib l,chunk c */);
void namesonly(/* lib l,chunk c */);
void commatosemi(/* lib l,chunk c */);
void lib_writestrtoid(/* int id,str s */);
void lib_writestatinfo(/* int id,str ext */);
void lib_writestructsub(/* int id,lib l,libstruct ls */);
void lib_writebuf(/* char *buf,int size */);
void lib_writeleaf(/* chunk c */);
void lib_writestr(/* str s */);
void lib_clearflag(/* lib l */);
void lib_setflag(/* lib l,int flag */);
char *libgen_stripdir(/* char *dir */);
void lib_include(/* lib l,chunk c0,chunk c1 */);
void lib_main(/* lib l,chunk c0 */);
void lib_maininitsub(/* lib l */);
void lib_mainquitsub(/* lib l */);
void lib_public(/* lib l,chunk c0 */);
void lib_writetypes(/* lib l,libstruct ls */);
void lib_init(/* lib l,chunk c0 */);
void lib_quit(/* lib l,chunk c0 */);
void lib_struct_(/* lib l,chunk c0,chunk c1 */);
void lib_application(/* lib l,chunk c0 */);
void lib_archive(/* lib l,chunk cp */);
void lib_init_exec();
void lib_execinit(/* str arg */);
void lib_execadd(/* str arg */);
void lib_exec();


int lib_idc,lib_idh;
int lib_inpublic,lib_lasttok;


void lib_init_libgen()
{
    lib_idc= -1; lib_idh= -1;
    lib_init_exec();
    lib_init_strlist();
}


/*
 * exit on error
 */

void libgen_exit()
{
    if (lib_idc>=0) close(lib_idc);
    if (lib_idh>=0) close(lib_idh);
    fprintf(stderr,"...exiting lib because of error\n");
    exit(1);
}

/*
 * check for lib_struct type names
 */

int lib_islibstruct(c)
chunk c;
{
    str name;
    libstruct ls;

    name=str_duplen(c->s,c->slen);
    ls=libstruct_find(name);
    mem_put(name,"lib_islibstruct");
    return ls?1:0;
}


/*
 * ========== string lists ==========
 */


typedef struct strlist_structdef {
    str s;
    struct strlist_structdef *sl0,*sl1;
} strlist_struct;

typedef strlist_struct *strlist;

strlist sl0,sl1;


void lib_init_strlist()
{
    sl0=(strlist)0; sl1=(strlist)0;
}

void strlist_init()
{
    strlist sl;

    while (sl0) {
        sl=sl0;
        if (sl->sl0) sl->sl0->sl1=sl->sl1; else sl0=sl->sl1;
        if (sl->sl1) sl->sl1->sl0=sl->sl0; else sl1=sl->sl0;
        mem_put(sl->s,"strlist_init");
        mem_put((char *)sl,"strlist_init");
    }
}

void strlist_add(s)
str s;
{
    strlist sl;

    sl=(strlist)mem_get(sizeof(strlist_struct),"strlist_add");
    sl->s=str_dup(s);
    sl->sl0=sl1; sl->sl1=(strlist)0;
    if (sl->sl0) sl->sl0->sl1=sl; else sl0=sl;
    if (sl->sl1) sl->sl1->sl0=sl; else sl1=sl;
}


/*
 * ========== preprocess, compile, archive and load all modules ==========
 */

void lib_genxsub(l,pass,comment)
lib l; int pass; char *comment;
{
    if (verbose) { printf("\n  ----  pass %d: %s  ----\n",pass,comment); }
    lib_genx(l,pass);
}

void lib_gen(l)
lib l;
{
    lib_genxsub(l,1,".l changed?");
    lib_genxsub(l,2,"done?");
    lib_genxsub(l,3,".h, .c");
    lib_genxsub(l,4,".o");
    lib_genxsub(l,5,".a");
    lib_genxsub(l,6,"external .a");
    lib_genxsub(l,7,"executables");
    lib_genxsub(l,8,".ldata");
}

/*
 * recursively perform gen pass
 */

int changes;

void lib_genx(l,pass)
lib l; int pass;
{
    strlist sl;
    libref lr;
    char buf[256];

    if (l->pass>=pass) return;
    l->pass=pass;
    libpath_push(l->dir,l->name);
    if (l->state==LIB_STATE_PROCESS) {
        switch (pass) {
        case 1:   /* .l changed? */
            if (l->buf) {
                l->changed=1;
                if (verbose) printf("%s.l is changed\n",libname());
            }else l->changed=0;
            break;
        case 2:   /* done? */
            for (changes=1;changes;) {
                changes=0; lib_clearflag(l); lib_changecheck(l);
            }
            if (!l->changed) {
                l->state=LIB_STATE_DONE;
                if (verbose) printf("%s.l is unchanged\n",libname());
            }else{
                if (!l->buf) {
                    lib_scan_loadgen=1;
                    lib_loadbuf(l);
                    lib_scan_loadgen=0;
                }
            }
            break;
        case 3:   /* .h, .c */
            if ((lib_idc=lib_openw(".c"))<0) {
                fprintf(stderr,"lib_genx: can't open %s.c\n",l->name);
                libgen_exit();
            }
            if ((l->type==LIB_PUBLIC || l->type==LIB_ARCHIVE) &&
                (lib_idh=lib_openw(".h"))<0) {
                fprintf(stderr,"lib_genx: can't open %s.h\n",l->name);
                libgen_exit();
            }
            lib_inpublic=0;
            sprintf(buf,
                "\n\n/********** %s.c created by lib **********/\n\n",
                l->name);
            lib_writestr(buf);
            if (l->type==LIB_EXECUTABLE || l->type==LIB_APPLICATION) {
                if (ls_root) lib_writetypes(l,ls_root);
            }
            if (l->type==LIB_PUBLIC || l->type==LIB_ARCHIVE) {
                if (!l->c_init) lib_init(l,(chunk)0);
                if (!l->c_quit) lib_quit(l,(chunk)0);
            }
            lib_scan_gen(l,l->c->cc0);
            if (lib_idc>=0) { close(lib_idc); lib_idc= -1; }
            if (lib_idh>=0) { close(lib_idh); lib_idh= -1; }
            break;
        case 4:   /* .o */
            lib_execinit(l->iscplusplus?"lib_CCobj":"lib_ccobj");
            lib_execadd(l->name);
            strlist_init(); lib_clearflag(l); lib_includepaths(l);
            for (sl=sl1;sl;sl=sl->sl0) lib_execadd(sl->s);
            lib_clearflag(l); lib_includepaths(l);
            lib_exec();
            sprintf(buf,"%s.o",l->name);
            if (!lib_isfile(".o")) {
                fprintf(stderr,"lib_scan_gen: %s not generated\n",buf);
                libgen_exit();
            }
            break;
        case 5:   /* .a */
            if (l->type==LIB_ARCHIVE) {
                lib_execinit("lib_ar");
                sprintf(buf,"%s.a",l->name);
                lib_execadd(buf);
                lib_clearflag(l); lib_ar(l);
                lib_exec();
                sprintf(buf,"%s.a",l->name);
                if (!lib_isfile(".a")) {
                    fprintf(stderr,"lib_scan_gen: %s not generated\n",buf);
                    libgen_exit();
                }
            }
            break;
        case 6:   /* external .a */
            for (lr=l->lr0;lr;lr=lr->lr1) {
                if (lr->type==LIB_GENEXEC)
                    { lib_execinit(lr->path); lib_exec(); }
            }
            break;
        case 7:   /* executables */
            if (l->type==LIB_EXECUTABLE) {
                lib_execinit(l->iscplusplus?"lib_CCexec":"lib_ccexec");
                lib_execadd(l->name);
                strlist_init(); lib_clearflag(l); lib_ccexec(l,0);
                for (sl=sl1;sl;sl=sl->sl0) lib_execadd(sl->s);
                lib_clearflag(l); lib_ccexec(l,0);
                lib_exec();
                if (!lib_isfile("")) {
                    fprintf(stderr,"lib_genx: %s not generated\n",l->name);
                    libgen_exit();
                }
            }
            break;
        case 8:   /* .ldata */
            {
                int id;
                char line[1024];

                if ((id=lib_openw(".ldata"))<0) libgen_exit();
                lib_writestatinfo(id,".l");
                lib_writestatinfo(id,".c");
                lib_writestatinfo(id,".h");
                lib_writestatinfo(id,".o");
                lib_writestatinfo(id,".a");
                lib_writestatinfo(id,"");
                sprintf(line,"type %s\n",lib_typestr(l->type));
                lib_writestrtoid(id,line);
                for (lr=l->lr0;lr;lr=lr->lr1) {
                    /* fix spaces to be ^'s for multiple load includes */
                    /* this is needed since .ldata reading works in "words" */
                    if (lr->load) {
                        int i;

                        for (i=0;lr->load[i];i++)
                            { if (lr->load[i]==' ') lr->load[i]='^'; }
                    }
                    sprintf(line,"%s %s %s %d %d\n",
                        lib_typestr(lr->type),lr->path,
                        (lr->load?lr->load:"-"),
                        (lr->l_to?lr->l_to->l_time:0),
                        (lr->l_to?lr->l_to->l_size:0));
                    lib_writestrtoid(id,line);
                }
                lib_writestructsub(id,l,ls_root);
                close(id);
            }
            break;
        }
    }
    for (lr=l->lr0;lr;lr=lr->lr1) {
        if (lr->l_to) lib_genx(lr->l_to,pass);
    }
    libpath_pop();
}

void lib_changecheck(l)
lib l;
{
    libref lr;

    if (l->flag) return;
    l->flag=1;
    for (lr=l->lr0;lr;lr=lr->lr1) {
        if (lr->l_to && (lr->type==LIB_PUBLIC || lr->type==LIB_ARCHIVE)) {
            lib_changecheck(lr->l_to);
            if (lr->l_to->changed && !l->changed) {
                l->changed=1;
                changes++;
                if (verbose) printf("%s.l is changed by module %s.l\n",
                    l->name,lr->l_to->name);
            }
        }
    }
}

void lib_ar(l)
lib l;
{
    libref lr;
    char buf[256];

    if (l->flag) return;
    l->flag=1;
    for (lr=l->lr0;lr;lr=lr->lr1) {
        if (lr->l_to && lr->type==LIB_ARCHIVE) {
            lib_ar(lr->l_to);
        }
    }
    sprintf(buf,"%s/%s.o",l->dir,l->name);
    lib_execadd(buf);
}

void lib_ccexec(l,inarchive)
lib l; int inarchive;
{
    libref lr;
    char buf[8192];

    if (l->flag) return;
    l->flag=1;
    switch (l->type) {
    case LIB_ARCHIVE:  sprintf(buf,"%s/%s.a",l->dir,l->name); break;
    case LIB_EXTERNAL: sprintf(buf,"%s",l->load?l->load:"");  break;
    default:           sprintf(buf,"%s/%s.o",l->dir,l->name); break;
    }
    for (lr=l->lr0;lr;lr=lr->lr1) {
        if (lr->l_to) {
            switch (lr->type) {
            case LIB_PUBLIC:
            case LIB_EXTERNAL:
                lib_ccexec(lr->l_to,0); break;
            case LIB_ARCHIVE:
                lib_ccexec(lr->l_to,l->type==LIB_ARCHIVE?1:0); break;
            default: break;
            }
        }
    }
    if (buf[0] && !inarchive) strlist_add(buf);
}

void lib_includepaths(l)
lib l;
{
    libref lr;
    char buf[256];

    if (l->flag) return;
    l->flag=1;
    if (l->includepath) sprintf(buf,"-I%s",l->includepath);
    else buf[0]='\0';
    for (lr=l->lr0;lr;lr=lr->lr1)
        { if (lr->l_to) lib_includepaths(lr->l_to); }
    if (buf[0]) strlist_add(buf);
}


/*
 * recursively scan chunk tree for gen preprocessing
 */

void lib_scan_gen(l,c)
lib l; chunk c;
{
    int t;

    for (;c;c=c->c1) {
        t=token(c);

        /*
         * this line turns off ANSII-to-K&R conversion.
         * To turn conversion back on, eliminate this line, or perform
         * action only if iscplusplus.
         * Better yet, this should be turned on optionally via an
         * environment variable.
         */
        if (/* l->iscplusplus && */ (t==TOK_FUNC || t==TOK_PROTO)) t=TOK_BLOCK;

        switch (t) {
        case TOK_ERROR:
            fprintf(stderr,"lib_scan_gen: bad lib token in %s at line %d\n",
                l->name,chunk_line(l->buf,c->s));
            libgen_exit();
            break;
        case TOK_LEAF:
            lib_writeleaf(c);
            break;
        case TOK_BLOCK:
            lib_writebuf(c->s,1);
            lib_scan_gen(l,c->cc0);
            lib_writebuf(c->s+(c->slen-1),1);
            break;
        case TOK_INCLUDE:
            lib_include(l,c->cc0,(c->cc0==c->cc1?(chunk)0:c->cc1));
            break;
        case TOK_CPLUSPLUS:
            break;
        case TOK_MAIN_EXTERNAL:
            break;
        case TOK_INCLUDEPATH:
            break;
        case TOK_MAIN:
            lib_main(l,c->cc0);
            break;
        case TOK_PUBLIC:
            lib_public(l,c->cc0);
            break;
        case TOK_INIT:
            lib_init(l,c->cc0);
            break;
        case TOK_QUIT:
            lib_quit(l,c->cc0);
            break;
        case TOK_STRUCT:
            lib_struct_(l,c->cc0,c->cc1);
            break;
        case TOK_APPLICATION:
            lib_application(l,c->cc0);
            break;
        case TOK_ARCHIVE:
            lib_archive(l,c->cc0);
            break;
        case TOK_FUNC:
            lib_writestr("(");
            namesonly(l,c->cc0);
            lib_writestr(")\n");
            commatosemi(l,c->cc0);
            lib_writestr(";");
            break;
        case TOK_PROTO:
            lib_writestr("(/* ");
            lib_scan_gen(l,c->cc0);
            lib_writestr(" */)");
            break;
        case TOK_GENEXEC:
        case TOK_CLEANEXEC:
        case TOK_CONFIGEXEC:
            break;
        default:
            fprintf(stderr,"libgen: unknown token\n");
            libgen_exit();
            break;
        }
    }
}

void namesonly(l,c)
lib l; chunk c;
{
    chunk a;

    for (a=(chunk)0;c;c=c->c1) {
        if (c->type=='a') a=c;
        if (c->type==',' || !c->c1) {
            if (!a) {
                fprintf(stderr,"lib: ansii name missing\n");
                fprintf(stderr,"  in %s at line %d\n",
                    l->name,chunk_line(l->buf,c->s));
                libgen_exit();
            }
            lib_writeleaf(a);
            if (c->type==',') lib_writestr(",");
            a=(chunk)0;
        }
    }
}

void commatosemi(l,c)
lib l; chunk c;
{
    for (;c;c=c->c1) {
        if (c->type==',') {
            lib_writestr("; ");
        }else lib_writeleaf(c);
    }
}

void lib_writestrtoid(id,s)
int id; str s;
{
    int size;

    size=str_len(s)-1;
    if (write(id,s,size)!=size) {
        fprintf(stderr,"lib: write failed for %s.ldata\n",libname());
        libgen_exit();
    }
}

void lib_writestatinfo(id,ext)
int id; str ext;
{
    int time,size;
    char line[1024];

    lib_statinfo(ext,&time,&size);
    if (size>0) {
        sprintf(line,"%s %d %d\n",(ext[0]?ext:".x"),time,size);
        lib_writestrtoid(id,line);
    }
}

void lib_writestructsub(id,l,ls)
int id; lib l; libstruct ls;
{
    char line[1024];

    if (!ls) return;
    lib_writestructsub(id,l,ls->ls0);
    if (ls->l==l) {
        sprintf(line,"struct %s\n",ls->name);
        lib_writestrtoid(id,line);
    }
    lib_writestructsub(id,l,ls->ls1);
}

void lib_writebuf(buf,size)
char *buf; int size;
{
    int id;

    id=lib_inpublic?lib_idh:lib_idc;
    if (write(id,buf,size)!=size) {
        fprintf(stderr,"lib: write failed for %s%s\n",
            libname(),lib_inpublic?".h":".c");
        libgen_exit();
    }
}

void lib_writeleaf(c)
chunk c;
{
    if (c->type=='#') lib_writestr("\n");
    if (c->type=='/') {
        int i;
        str cmt;

        cmt=str_duplen(c->s+2,c->slen-3);
        for (i=0;cmt[i];i++) {
            if (cmt[i]=='/' && cmt[i+1]=='*') cmt[i+1]='-';
            if (cmt[i]=='*' && cmt[i+1]=='/') cmt[i]='-';
        }
        lib_writestr("/*");
        lib_writestr(cmt);
        if (cmt[i-1]!=' ') lib_writestr(" */\n");
        else               lib_writestr("*/\n");
        mem_put(cmt,"lib_writeleaf");
        return;
    }
    lib_writebuf(c->s,c->slen);
}

void lib_writestr(s)
str s;
{
    lib_writebuf(s,str_len(s)-1);
}

void lib_clearflag(l)
lib l;
{
    lib_setflag(l,0xdeadbeed);
    lib_setflag(l,0);
}

void lib_setflag(l,flag)
lib l; int flag;
{
    libref lr;

    if (l->flag==flag) return;
    l->flag=flag;
    for (lr=l->lr0;lr;lr=lr->lr1) if (lr->l_to) lib_setflag(lr->l_to,flag);
}

char *libgen_stripdir(char *dir)
{
    static char sdir[1024];
    int j;

    for (j=0;dir[j]==libhome[j];j++) ;
    while (j>0 && dir[j]=='/') j++;
    sprintf(sdir,"%s",dir+j);
    return sdir;
}

void lib_include(l,c0,c1)
lib l; chunk c0; chunk c1;
{
    str path,path0,ext;
    char buf[256];

    path=str_unquote(c0->s);
    ext=str_lastdot(path);
    path0=str_duplen(path,ext-path);
    sprintf(buf,"/* lib_include \"%s\" */\n#include \"%s.h\"\n",path,path0);
    lib_writestr(buf);
    mem_put(path0,"lib_include");
    mem_put(path,"lib_include");
}

void lib_main(l,c0)
lib l; chunk c0;
{
    strlist sl;
    char line[256];

    lib_writestr("\n\nint libargc;\nchar **libargv;\nchar **libenvp;\n\n");
    sprintf(line,"\nint main(argc,argv,envp)\n");
    lib_writestr(line);
    lib_writestr("int argc; char **argv; char **envp;\n{\n");
    lib_writestr("    libargc=argc; libargv=argv; libenvp=envp;\n\n");
    strlist_init(); lib_clearflag(l); lib_maininitsub(l);
    for (sl=sl0;sl;sl=sl->sl1) lib_writestr(sl->s);
    lib_scan_gen(l,c0);
    lib_writestr("\n");
    strlist_init(); lib_clearflag(l); lib_mainquitsub(l);
    for (sl=sl1;sl;sl=sl->sl0) lib_writestr(sl->s);
    lib_writestr("    exit(0);\n");
    lib_writestr("}\n");
}

void lib_maininitsub(l)
lib l;
{
    libref lr;
    char buf[256];

    if (l->flag) return;
    l->flag=1;
    for (lr=l->lr0;lr;lr=lr->lr1) {
        if ((lr->type==LIB_PUBLIC || lr->type==LIB_ARCHIVE) && lr->l_to)
            lib_maininitsub(lr->l_to);
    }
    if (l->type!=LIB_EXECUTABLE) {
        sprintf(buf,"    lib_init_%s();\n",l->name);
        strlist_add(buf);
    }
}

void lib_mainquitsub(l)
lib l;
{
    libref lr;
    char buf[256];

    if (l->flag) return;
    l->flag=1;
    for (lr=l->lr0;lr;lr=lr->lr1)
        if ((lr->type==LIB_PUBLIC || lr->type==LIB_ARCHIVE) && lr->l_to)
            lib_mainquitsub(lr->l_to);
    if (l->type!=LIB_EXECUTABLE) {
        sprintf(buf,"    lib_quit_%s();\n",l->name);
        strlist_add(buf);
    }
}

void lib_public(l,c0)
lib l; chunk c0;
{
    lib lx,l_archive;
    libref lr,lxr;
    char buf[256];

    /*
     * put .h include in .c file
     */
    sprintf(buf,"\n/* lib_public include: */\n#include \"%s.h\"\n\n",l->name);
    lib_writestr(buf);

    /*
     * make extern references to executable's lib globals for this library
     */
    lib_writestr("\n\nextern int libargc;\n");
    lib_writestr("extern char **libargv;\n");
    lib_writestr("extern char **libenvp;\n\n");

    /*
     * start .h file
     */
    lib_inpublic=1;
    sprintf(buf,"\n\n/********** %s.h created by lib **********/\n\n",l->name);
    lib_writestr(buf);

    /*
     * find any l_archive containing l that l includes
     */
    l_archive=(lib)0;
    for (lx=lib0;lx;lx=lx->l1) {
        for (lxr=lx->lr0;lxr;lxr=lxr->lr1) {
            if (lxr->type==LIB_ARCHIVE && lxr->l_to==l) {
                for (lr=l->lr0;lr;lr=lr->lr1) {
                    if (lr->l_to==lx) l_archive=lx;
                }
            }
        }
    }

    /*
     * type section of header
     */
    sprintf(buf,"\n#ifndef LIB_%s__TYPE\n",l->name);
    lib_writestr(buf);
    sprintf(buf,"\n#define LIB_%s__TYPE 1\n",l->name);
    lib_writestr(buf);
    /*
     * do type includes
     */
    for (lr=l->lr0;lr;lr=lr->lr1) {
        if (lr->l_to && (lr->type==LIB_PUBLIC || lr->type==LIB_ARCHIVE)) {
            sprintf(buf,"\n#ifndef LIB_%s__TYPEONLY\n",lr->l_to->name);
            lib_writestr(buf);
            sprintf(buf,"\n#define LIB_%s__TYPEONLY 1\n",lr->l_to->name);
            lib_writestr(buf);
            sprintf(buf,"\n#include \"%s/%s.h\"\n",
                libgen_stripdir(lr->l_to->dir),lr->l_to->name);
            lib_writestr(buf);
            sprintf(buf,"\n#undef LIB_%s__TYPEONLY\n",lr->l_to->name);
            lib_writestr(buf);
            sprintf(buf,"\n#else\n");
            lib_writestr(buf);
            sprintf(buf,"\n#include \"%s/%s.h\"\n",
                libgen_stripdir(lr->l_to->dir),lr->l_to->name);
            lib_writestr(buf);
            sprintf(buf,"\n#endif\n");
            lib_writestr(buf);
        }
    }
    /*
     * define types
     */
    if (ls_root) lib_writetypes(l,ls_root);
    /*
     * end of type section
     */
    sprintf(buf,"\n#endif\n\n");
    lib_writestr(buf);

    /*
     * body of header
     */
    sprintf(buf,"\n#ifndef LIB_%s__TYPEONLY\n",l->name);
    lib_writestr(buf);

    if (l_archive) {
        sprintf(buf,"\n#ifndef LIB_%s__HERE\n",l_archive->name);
        lib_writestr(buf);
        sprintf(buf,"\n#include \"%s/%s.h\"\n",
            libgen_stripdir(l_archive->dir),l_archive->name);
        lib_writestr(buf);
        sprintf(buf,"\n#else\n");
        lib_writestr(buf);
    }

    sprintf(buf,"\n#ifndef LIB_%s__HERE\n",l->name);
    lib_writestr(buf);
    sprintf(buf,"\n#define LIB_%s__HERE 1\n",l->name);
    lib_writestr(buf);
    sprintf(buf,"\nvoid lib_init_%s();\n",l->name);
    lib_writestr(buf);
    sprintf(buf,"\nvoid lib_quit_%s();\n",l->name);
    lib_writestr(buf);
    lib_scan_gen(l,c0->cc0);
    sprintf(buf,"\n#endif\n\n");
    lib_writestr(buf);

    if (l_archive) {
        sprintf(buf,"\n#endif\n");
        lib_writestr(buf);
    }

    sprintf(buf,"\n#endif\n\n");
    lib_writestr(buf);

    /*
     * done writing header
     */
    lib_inpublic=0;
}

void lib_writetypes(l,ls)
lib l; libstruct ls;
{
    char buf[256];

    if (ls->ls0) lib_writetypes(l,ls->ls0);
    if (ls->l==l) {
        sprintf(buf,"\ntypedef struct %s_structdef %s_struct,*%s;\n",
            ls->name, ls->name, ls->name);
        lib_writestr(buf);
    }
    if (ls->ls1) lib_writetypes(l,ls->ls1);
}

void lib_init(l,c0)
lib l; chunk c0;
{
    strlist sl;
    char buf[256];

    if (!l->isextmain) {
        sprintf(buf,
            "\n\n/*\n * lib_init for %s\n */\n\nvoid lib_init_%s()\n{\n",
            l->name,l->name);
        lib_writestr(buf);
        if (c0) lib_scan_gen(l,c0->cc0);
        sprintf(buf,"\n}\n\n");
        lib_writestr(buf);
    }else{
        lib_writestr("\n");
        strlist_init(); lib_clearflag(l); lib_maininitsub(l);
        for (sl=sl0;sl;sl=sl->sl1) lib_writestr(sl->s);
        lib_writestr("\n");
    }
}

void lib_quit(l,c0)
lib l; chunk c0;
{
    strlist sl;
    char buf[256];

    if (!l->isextmain) {
        sprintf(buf,
            "\n\n/*\n * lib_quit for %s\n */\n\nvoid lib_quit_%s()\n{\n",
            l->name,l->name);
        lib_writestr(buf);
        if (c0) lib_scan_gen(l,c0->cc0);
        sprintf(buf,"\n}\n\n");
        lib_writestr(buf);
    }else{
        lib_writestr("\n");
        strlist_init(); lib_clearflag(l); lib_mainquitsub(l);
        for (sl=sl1;sl;sl=sl->sl0) lib_writestr(sl->s);
        lib_writestr("\n");
    }
}

void lib_struct_(l,c0,c1)
lib l; chunk c0; chunk c1;
{
    int i;
    char buf[256],sname[256];

    for (i=0;i<c1->slen;i++) sname[i]=c1->s[i];
    sname[i]='\0';
    sprintf(buf,"\n\n/*\n * lib_struct %s\n */\n\n",sname);
    lib_writestr(buf);
    sprintf(buf,"struct %s_structdef {",sname);
    lib_writestr(buf);
    lib_scan_gen(l,c0->cc0);
    sprintf(buf,"};\n");
    lib_writestr(buf);
}

void lib_application(l,c0)
lib l; chunk c0;
{
    int i;
    char path[256],buf[256];

    for (i=0;i<c0->slen;i++) path[i]=c0->s[i];
    path[i]='\0';
    sprintf(buf,"/* lib_application %s */\n",path);
    lib_writestr(buf);
}

void lib_archive(l,cp)
lib l; chunk cp;
{
    chunk ca;
    str path,path0,ext;
    char buf[256];

    if (!cp) return;
    ca=cp->cc0; if (ca) lib_skipwhite(&ca);
    while (ca) {
        path=str_unquote(ca->s);
        ext=str_lastdot(path);
        path0=str_duplen(path,ext-path);
        sprintf(buf,"/* lib_archive \"%s\" */\n#include \"%s.h\"\n",
            path,path0);
        lib_writestr(buf);
        mem_put(path0,"lib_archive");
        mem_put(path,"lib_archive");
        ca=ca->c1;
        if (ca) lib_skipwhite(&ca);
        if (ca && ca->type==',') ca=ca->c1;
        if (ca) lib_skipwhite(&ca);
    }
}


/*
 * ========== execute unix command ==========
 */

int exec_caught,exec_argc,exec_errors;
str *ex_argv;

void lib_init_exec()
{
    exec_argc=0; ex_argv=(str *)0;
}

void handler(sig)
int sig;
{
    int pid;
    int status;

    while ((pid=wait3(&status,WNOHANG,(struct rusage *)0))>0) {
        exec_caught++;
        if (WIFSTOPPED(status) ||
            (WIFEXITED(status) && WEXITSTATUS(status))) {
printf("lib_gen handler(): pid=%d status=0x%x\n",pid,status);
fflush(stdout);
            exec_errors++;
        }
    }
    signal(SIGCHLD,handler);

/***********************
    int pid,nextin;
    union wait status;

    while ((pid=wait3((int *)(&status),WNOHANG,(struct rusage *)0))>0) {
        exec_caught++;
        if (status.w_status) {
printf("lib_gen handler(): pid=%d w_status=%d\n",pid,status.w_status);
fflush(stdout);
            exec_errors++;
        }
    }
    signal(SIGCHLD,handler);
***********************/
}

void lib_execinit(arg)
str arg;
{
    int i;

    if (exec_argc) {
        for (i=0;i<exec_argc;i++) mem_put(ex_argv[i],"lib_execinit");
        mem_put((char *)ex_argv,"lib_execinit");
    }
    exec_argc=1;
    ex_argv=(str *)mem_get((exec_argc+1)*sizeof(str),"lib_execinit");
    ex_argv[0]=str_dup(arg);
    ex_argv[1]=(str)0;
}

void lib_execadd(arg)
str arg;
{
    int i,argc;
    str *argv;

    argc=exec_argc+1;
    argv=(str *)mem_get((argc+1)*sizeof(str),"lib_execinit");
    for (i=0;i<exec_argc;i++) {
        argv[i]=ex_argv[i];
    }
    argv[exec_argc]=str_dup(arg);
    argv[argc]=(str)0;
    mem_put((char *)ex_argv,"lib_execadd");
    ex_argv=argv;
    exec_argc=argc;
}

void lib_exec()
{
    int pid;
    struct timeval tv;

    if (verbose) {
        int i;

        printf("lib_exec: --- EXEC ---");
        for (i=0;i<exec_argc;i++) printf(" %s",ex_argv[i]);
        printf("\n"); fflush(stdout);
    }
    exec_caught=0; exec_errors=0;
    signal(SIGCHLD,handler);
    if ((pid=fork())) {
        if (verbose)
            { printf("lib_exec parent: pid=%d\n",pid); fflush(stdout); }
        tv.tv_sec=0; tv.tv_usec=1000;
        while (select(0,0,0,0,&tv)>=0 && !exec_caught) {
            tv.tv_sec=0; tv.tv_usec=50000;
        }
        if (!exec_caught) {
            fprintf(stderr,"lib_exec: select()/signal catching failed\n");
            exit(1);
        }
        if (exec_errors) {
            fprintf(stderr,"lib_exec: %s failed\n",ex_argv[0]);
            exit(1);
        }
    }else{
        if (verbose) {
            int i;

             printf("lib_exec child: argv=["); fflush(stdout);
             for (i=0;i<exec_argc;i++) printf(" %s",ex_argv[i]);
             printf("]\n"); fflush(stdout);
        }
        execvp(ex_argv[0],ex_argv);
        fprintf(stderr,"lib_exec: can't exec %s\n",ex_argv[0]);
        exit(1);
    }
}


