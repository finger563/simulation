
/*
 * lib.c                                                 c library support
 * by Mark Duchaineau (free but copyrighted, see LibGen/COPYING)
 *
 * See README for documentation
 *
 * 12-03-92: first working version
 * 01-08-94: major update
 *           1) lib.c split up
 *           2) better error handling
 *           3) version checking
 *           4) archive modules
 *           5) automatic addition of lib_init and lib_quit via lib_main()
 *           6) no need for @'s or lib_executable's
 *           7) proper handling of module hierarchies
 * 03-11-94: 8) lib_init/lib_quit are now optional for public modules
 *           9) use of .ldata (file time/size, etc...) instead of .lprev
 * 03-18-94: 9a) added stat check on .l includes for gen
 *           10) allow C++-style comments (// ...)
 *           11) verbose option controlled by environment variable LIB_VERBOSE
 *           12) lib_CC directive to select CC (i.e. C++) compilations
 * 08-01-97: consolidated changes from home here
 * 09-21-99: changed libgen.c to generate globals lib{argc,argv,envp}
 * 03-24-02: allow hardware-specific submodules after tuning *exec directives
 *
 * NOTE: see submodules for specific update notes
 *
 */

#define LIB_MODE_NONE         0
#define LIB_MODE_GEN          1
#define LIB_MODE_CLEAN        2

int verbose;                                 /* 0=summary, 1=details         */
int mode;                                    /* see defs above               */

#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <unistd.h>

#include "lib_home.h"
#include "mem.c"
#include "str.c"
#include "libpath.c"
#include "file.c"
#include "chunk.c"
#include "tok.c"
#include "libinfo.c"
#include "libgen.c"

#define LIBENV_UNKNOWN 0
#define LIBENV_VERBOSE 1

void usage_exit();
int libgetenv(/* char *envline,char **envdef */);

int main(argc,argv,envp)
int argc; char **argv; char **envp;
{
    int i;
    lib l;
    char *envdef;

    /*
     * initialize all modules
     */
    verbose=0; mode=LIB_MODE_NONE;
    lib_init_mem();
    lib_init_str();
    lib_init_libpath();
    lib_init_file();
    lib_init_chunk();
    lib_init_tok();
    lib_init_libinfo();
    lib_init_libgen();

    /*
     * process environment variables
     */
    for (i=0;envp[i];i++) {
        switch (libgetenv(envp[i],&envdef)) {
        case LIBENV_VERBOSE:
            if (envdef[0]=='1') verbose=1;
            break;
        default:
            break;
        }
    }

    /*
     * determine mode from command line
     */
    if (argc<2) usage_exit();
    if (str_cmp(argv[1],"gen")) mode=LIB_MODE_GEN;
    else{
        if (str_cmp(argv[1],"clean")) mode=LIB_MODE_CLEAN;
        else usage_exit();
    }

    /*
     * process each source file command-line argument
     */
    for (i=2;i<argc;i++) {
        l=lib_load(argv[i]);
        switch (mode) {
        case LIB_MODE_GEN:    lib_gen(l);    break;
        case LIB_MODE_CLEAN:  lib_clean(l);  break;
        default: break;
        }
        while (lib0) lib_destroy(lib0);
    }
    printf("lib successfully completed\n");
    exit(0);
}

/*
 * print usage help message and exit
 */

void usage_exit()
{
    fprintf(stderr,"usage: lib {gen|clean} foo.l ...\n");
    exit(1);
}

int libgetenv(envline,renvdef)
char *envline; char **renvdef;
{
    char *eq,*s,*t;
    char ts[1024];

    for (eq=envline;*eq && *eq!='=';eq++) ;
    for (s=(*eq?eq+1:eq);*s==' ';s++) ;
    *renvdef=s;
    if (eq-envline>1020) return LIBENV_UNKNOWN;
    for (s=envline,t=ts;s<eq;) *t++ = *s++;
    *t++ ='\0';
    if (str_cmp("LIB_VERBOSE",ts)) return LIBENV_VERBOSE;
    return LIBENV_UNKNOWN;
}


