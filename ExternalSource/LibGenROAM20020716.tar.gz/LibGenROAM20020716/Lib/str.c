
/*
 * str.c                                                        string support
 * by Mark Duchaineau (free but copyrighted, see LibGen/COPYING)
 *
 * 11-27-92: wrote (char type checking)
 * 12-21-93: put all string support here
 * 07-11-96: enhanced _unquote to interpret backslashes
 * 09-10-00: fixed missing second arg in mem_get() call
 *
 */


typedef char *str;


void lib_init_str()
{
}


/*
 * ========== string support ==========
 */

int str_scmp(a,b)
char *a,*b;
{
    while (*a && (*a == *b)) { a++; b++; }
    return *a<*b ? -1
                 : *a>*b ? 1 : 0;
}

int str_cmp(a,b)
char *a,*b;
{
    return str_scmp(a,b)?0:1;
}

char *str_lastof(s,c)
char *s; char c;
{
    char *last;

    last="";
    for (;*s;s++) if (*s==c) last=s;
    return last;
}

char *str_lastdot(name)
char *name;
{
    return str_lastof(name,'.');
}

int str_len(s)
char *s;
{
    int n;

    for (n=0;s[n++];) ;
    return n;
}

char *str_dup(s)
char *s;
{
    int n;
    char *t;

    t=mem_get(str_len(s),"strdup");
    for (n=0;(t[n]=s[n]);n++) ;
    return t;
}

char *str_duplen(s,n)
char *s; int n;
{
    int i;
    char *t;

    t=mem_get(n+1,"str_duplen");
    for (i=0;i<n;i++) t[i]=s[i];
    t[n]='\0';
    return t;
}

char *str_unquote(s)
char *s;
{
    int n,i,j;
    char *t,*q;

    for (n=1;s[n] && s[n]!='"';n++) ;
    t=mem_get(n+1,"str_unquote");
    for (i=1,j=0;i<n;i++) {
        if (s[i]=='\\') {
            switch (s[i+1]) {
            case 'n':
                t[j++]='\n';
                break;
            case '\\':
                t[j++]='\\';
                break;
            case '\n':
                break;
            default:
                fprintf(stderr,"str_unquote: unknown backslash case\n");
                break;
            }
            i++;
        }else t[j++]=s[i];
    }
    q=str_duplen(t,j);
    mem_put(t,"str_unquote");
    return q;
}

str str_concat(s1,s2)
str s1; str s2;
{
    int i,j;
    str s;

    s=mem_get(str_len(s1)+str_len(s2)-1,"str_concat");
    for (i=0,j=0;s1[j];) s[i++]=s1[j++];
    for (j=0;s2[j];) s[i++]=s2[j++];
    s[i]='\0';
    return s;
}


/*
 * ========== char type checking ==========
 */

int is_alpha(ch)
int ch;
{
    return((ch>='a' && ch<='z') ||
        (ch>='A' && ch<='Z') ||
        ch=='_');
}

int is_alphanum(ch)
int ch;
{
    return((ch>='a' && ch<='z') ||
        (ch>='A' && ch<='Z') ||
        (ch>='0' && ch<='9') || ch=='_');
}

int is_hex(ch)
int ch;
{
    return((ch>='a' && ch<='f') ||
        (ch>='A' && ch<='F') ||
        (ch>='0' && ch<='9'));
}

int is_num(ch)
int ch;
{
    return(ch>='0' && ch<='9');
}

int is_oct(ch)
int ch;
{
    return(ch>='0' && ch<='7');
}

int is_namechar(ch)
int ch;
{
    return((ch>='a' && ch<='z') ||
        (ch>='A' && ch<='Z') ||
        (ch>='0' && ch<='9') || ch=='_' || ch=='-');
}


