
#ifndef SPINDEFS__HERE
#define SPINDEFS__HERE 1

// spindefs.l (IRIX version) hardware-specific flags for spin.l applications
// by Mark Duchaineau (free but copyrighted, see LibGen/COPYING)
//
// 07-03-02: wrote

// define named hardware
#define SPIN__IRIX 1

// uncomment selected options (value is not used for now)
#define SPIN__STRIP 1
//#define SPIN__ISTRIP 1
#define SPIN__DISPLAYLIST 1


#endif

