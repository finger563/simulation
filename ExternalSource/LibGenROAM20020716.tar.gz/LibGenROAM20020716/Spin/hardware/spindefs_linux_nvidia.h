
#ifndef SPINDEFS__HERE
#define SPINDEFS__HERE 1

// spindefs.l (Linux Nvidia version) hardware-specific flags for spin.l apps
// by Mark Duchaineau (free but copyrighted, see LibGen/COPYING)
//
// 07-03-02: wrote

// define named hardware
#define SPIN__NVIDIA 1

// uncomment selected options (value is not used for now)
#define SPIN__STRIP 1
#define SPIN__ISTRIP 1
//#define SPIN__DISPLAYLIST 1


// if your GL/gl.h header allready has this Nvidia-specific
// information, then you should skip the following. 

#ifdef SPIN__NVIDIA
    #ifndef GL_VERTEX_ARRAY_RANGE_NV
        #define GL_VERTEX_ARRAY_RANGE_NV             0x851D
        #define GL_VERTEX_ARRAY_RANGE_LENGTH_NV      0x851E
        #define GL_VERTEX_ARRAY_RANGE_VALID_NV       0x851F 
        #define GL_MAX_VERTEX_ARRAY_RANGE_ELEMENT_NV 0x8520
        #define GL_VERTEX_ARRAY_RANGE_POINTER_NV     0x8521
    #endif
    #ifndef GL_ALL_COMPLETED_NV
        #define GL_ALL_COMPLETED_NV 0x84F2
    #endif
    
    void *glXAllocateMemoryNV(int size, float readFrequency,
        float writeFrequency, float priority);    
    void glDrawRangeElements( GLenum mode, GLuint start, GLuint end,
        GLsizei count, GLenum type, const GLvoid *indices );
    void glGenFencesNV(GLsizei n, GLuint *fences);
    void glSetFenceNV(GLuint fence, GLenum condition);
    GLboolean glTestFenceNV(GLuint fence);
    void glFinishFenceNV(GLuint fence);
#endif


#endif

